import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev-time proxy: the React app calls "/api/..." and Vite forwards it to the
// Express server on port 5000. This avoids dealing with CORS during
// development and means the frontend code never hardcodes a backend URL.
export default defineConfig({
    plugins: [react()],
    server: {
        port: 5173,
        proxy: {
            '/api': {
                target: 'http://localhost:5000',
                changeOrigin: true
            }
        }
    }
});
