// utils/dateUtils.js
// Small shared helpers so date/time conversions are done consistently
// everywhere, using the BROWSER'S LOCAL time rather than UTC. This matters
// because:
//   1. The backend stores datetimes as naive strings (no timezone) — what an
//      admin types in as "10:00 AM" is stored literally as "10:00:00".
//   2. When read back, the API serializes it as an ISO string with "Z" (UTC)
//      because of how the MySQL driver converts DATETIME columns to JS Date
//      objects. That "Z" does NOT mean the time is actually UTC — it's an
//      artifact of the round trip.
//   3. So converting an ISO string back into local Y-M-D/H:M pieces must use
//      Date's LOCAL getters (getHours, getDate, etc.), never getUTCHours or
//      toISOString(), or the displayed time will be wrong by your timezone
//      offset (e.g. off by 5:30 in India).

function pad(n) {
    return String(n).padStart(2, '0');
}

// Today's date as "YYYY-MM-DD", in the browser's local timezone.
export function todayLocalISODate() {
    const d = new Date();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// Current time as "HH:MM", in the browser's local timezone.
export function nowLocalTime() {
    const d = new Date();
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// Converts an ISO datetime string (as returned by the API) into the value a
// <input type="datetime-local"> expects: "YYYY-MM-DDTHH:MM", in local time.
export function toDatetimeLocalValue(isoString) {
    if (!isoString) return '';
    const d = new Date(isoString);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
