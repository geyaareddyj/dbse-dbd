// pages/NotFound.jsx
import { Link } from 'react-router-dom';

function NotFound() {
    return (
        <div className="page-container text-center" style={{ paddingTop: 80 }}>
            <h2>Page not found</h2>
            <p>The page you're looking for doesn't exist.</p>
            <Link to="/login" className="btn btn-primary">Go to Login</Link>
        </div>
    );
}

export default NotFound;
