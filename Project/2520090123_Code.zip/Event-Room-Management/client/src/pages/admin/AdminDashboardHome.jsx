// pages/admin/AdminDashboardHome.jsx
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getRooms, checkRoomAvailability } from '../../services/roomService';
import { getEvents } from '../../services/eventService';
import { getAllRegistrations } from '../../services/registrationService';
import { getOccupancyRecords } from '../../services/occupancyService';
import { LoadingState, ErrorState } from '../../components/DataStates.jsx';
import { getErrorMessage } from '../../services/api';
import { todayLocalISODate } from '../../utils/dateUtils.js';

function formatDateTime(dt) {
    return new Date(dt).toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// "Occupied right now" is computed by asking the SAME availability endpoint
// used everywhere else in the app for a 1-minute window starting this
// instant — reusing the core conflict-detection logic rather than building a
// separate "live status" query. Uses local time throughout (see dateUtils.js
// for why toISOString()/UTC getters would be wrong here).
function nowWindow() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');

    const startTime = `${pad(now.getHours())}:${pad(now.getMinutes())}`;

    const later = new Date(now.getTime() + 60000);
    const endTime = `${pad(later.getHours())}:${pad(later.getMinutes())}`;

    return {
        date: todayLocalISODate(),
        startTime,
        endTime
    };
}

function AdminDashboardHome() {
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');
    const [stats, setStats] = useState(null);
    const [upcomingEvents, setUpcomingEvents] = useState([]);
    const [capacityWarnings, setCapacityWarnings] = useState([]);
    const [occupancyRecords, setOccupancyRecords] = useState([]);

    useEffect(() => {
        async function load() {
            setStatus('loading');

            try {
                const [
                    rooms,
                    events,
                    registrations,
                    liveAvailability,
                    occupancyData
                ] = await Promise.all([
                    getRooms(),
                    getEvents(),
                    getAllRegistrations(),
                    checkRoomAvailability(nowWindow()),
                    getOccupancyRecords()
                ]);

                const now = new Date();
                const todayStr = now.toDateString();

                const occupiedNow = liveAvailability.unavailable.filter(
                    (r) =>
                        r.reason.startsWith('Already booked') ||
                        r.reason.toLowerCase().includes('inactive')
                ).length;

                const availableNow = liveAvailability.available.length;

                const upcoming = events
                    .filter((e) => new Date(e.start_date) > now)
                    .sort(
                        (a, b) =>
                            new Date(a.start_date) -
                            new Date(b.start_date)
                    );

                const todaysEvents = events.filter(
                    (e) =>
                        new Date(e.start_date).toDateString() === todayStr
                );

                // Capacity warnings:
                // 1. Expected participants exceed room capacity
                // 2. Actual occupancy exceeds room capacity
                const warnings = events.filter((e) => {
                    const expectedOverCapacity =
                        e.room_capacity &&
                        e.expected_participants > e.room_capacity;

                    const occupancyOverCapacity = occupancyData.some(
                        (record) =>
                            record.event_id === e.event_id &&
                            record.room_capacity &&
                            record.actual_occupancy >
                                record.room_capacity
                    );

                    return (
                        expectedOverCapacity ||
                        occupancyOverCapacity
                    );
                });

                setStats({
                    totalRooms: rooms.length,
                    availableNow,
                    occupiedNow,
                    upcomingCount: upcoming.length,
                    todaysCount: todaysEvents.length,
                    registrationsCount: registrations.length
                });

                setUpcomingEvents(upcoming.slice(0, 5));
                setCapacityWarnings(warnings);
                setOccupancyRecords(occupancyData);

                setStatus('success');
            } catch (err) {
                setErrorMessage(getErrorMessage(err));
                setStatus('error');
            }
        }

        load();
    }, []);

    if (status === 'loading') {
        return <LoadingState message="Loading dashboard..." />;
    }

    if (status === 'error') {
        return <ErrorState message={errorMessage} />;
    }

    return (
        <div>
            <h2>Admin Dashboard</h2>

            <div
                className="card-grid"
                style={{ marginBottom: 24 }}
            >
                <div className="card stat-card">
                    <div className="stat-value">
                        {stats.totalRooms}
                    </div>
                    <div className="stat-label">
                        Total Rooms
                    </div>
                </div>

                <div className="card stat-card">
                    <div
                        className="stat-value"
                        style={{
                            color: 'var(--color-success)'
                        }}
                    >
                        {stats.availableNow}
                    </div>
                    <div className="stat-label">
                        Available Right Now
                    </div>
                </div>

                <div className="card stat-card">
                    <div
                        className="stat-value"
                        style={{
                            color: 'var(--color-danger)'
                        }}
                    >
                        {stats.occupiedNow}
                    </div>
                    <div className="stat-label">
                        Occupied Right Now
                    </div>
                </div>

                <div className="card stat-card">
                    <div className="stat-value">
                        {stats.upcomingCount}
                    </div>
                    <div className="stat-label">
                        Upcoming Events
                    </div>
                </div>

                <div className="card stat-card">
                    <div className="stat-value">
                        {stats.todaysCount}
                    </div>
                    <div className="stat-label">
                        Today's Events
                    </div>
                </div>

                <div className="card stat-card">
                    <div className="stat-value">
                        {stats.registrationsCount}
                    </div>
                    <div className="stat-label">
                        Total Registrations
                    </div>
                </div>
            </div>

            <div
                className="form-row"
                style={{ alignItems: 'stretch' }}
            >
                <div
                    className="card"
                    style={{ flex: 2, minWidth: 300 }}
                >
                    <h3>Upcoming Events</h3>

                    {upcomingEvents.length === 0 && (
                        <p className="text-muted">
                            No upcoming events.
                        </p>
                    )}

                    {upcomingEvents.length > 0 && (
                        <div className="table-wrap">
                            <table className="responsive-table">
                                <thead>
                                    <tr>
                                        <th>Event</th>
                                        <th>Start</th>
                                        <th>Room</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {upcomingEvents.map((e) => (
                                        <tr key={e.event_id}>
                                            <td data-label="Event">
                                                {e.event_name}
                                            </td>

                                            <td data-label="Start">
                                                {formatDateTime(
                                                    e.start_date
                                                )}
                                            </td>

                                            <td data-label="Room">
                                                {e.room_number || (
                                                    <span className="text-muted">
                                                        Not assigned
                                                    </span>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    <div style={{ marginTop: 12 }}>
                        <Link
                            to="/admin/events"
                            className="btn btn-secondary btn-sm"
                        >
                            View all events
                        </Link>
                    </div>
                </div>

                <div
                    className="card"
                    style={{ flex: 1, minWidth: 260 }}
                >
                    <h3>Capacity Warnings</h3>

                    {capacityWarnings.length === 0 && (
                        <p className="text-muted">
                            No capacity problems detected. The system
                            also prevents new scheduling conflicts
                            automatically at the point a room is
                            assigned, so none can exist here.
                        </p>
                    )}

                    {capacityWarnings.map((e) => {
                        const occupancyRecord =
                            occupancyRecords.find(
                                (record) =>
                                    record.event_id === e.event_id
                            );

                        const actualOverCapacity =
                            occupancyRecord &&
                            occupancyRecord.room_capacity &&
                            occupancyRecord.actual_occupancy >
                                occupancyRecord.room_capacity;

                        return (
                            <div
                                key={e.event_id}
                                className="alert alert-danger"
                                style={{ marginBottom: 8 }}
                            >
                                <strong>
                                    {e.event_name}
                                </strong>
                                :{' '}

                                {actualOverCapacity
                                    ? `actual occupancy is ${occupancyRecord.actual_occupancy}, but ${e.room_number} holds only ${e.room_capacity}.`
                                    : `expects ${e.expected_participants} but ${e.room_number} holds only ${e.room_capacity}.`
                                }
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

export default AdminDashboardHome;