// pages/admin/ManageRooms.jsx
import { useState, useEffect, useCallback } from 'react';
import { getRooms, createRoom, updateRoom, deleteRoom, ROOM_TYPES, ROOM_STATUSES } from '../../services/roomService';
import { getErrorMessage } from '../../services/api';
import { useToast } from '../../context/ToastContext.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import Modal from '../../components/Modal.jsx';
import ConfirmDialog from '../../components/ConfirmDialog.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

const EMPTY_FORM = { roomName: '', roomNumber: '', building: '', capacity: '', roomType: 'Classroom', equipment: '', status: 'Available' };

function ManageRooms() {
    const { showToast } = useToast();
    const [rooms, setRooms] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');

    const [search, setSearch] = useState('');
    const [filterStatus, setFilterStatus] = useState('');

    const [editingRoom, setEditingRoom] = useState(null); // null = not editing, {} = adding new, object = editing that room
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState('');
    const [saving, setSaving] = useState(false);

    // Shown when a capacity reduction would affect upcoming events —
    // holds the pending form data plus the list of affected events.
    const [capacityWarning, setCapacityWarning] = useState(null);
    const [roomToDelete, setRoomToDelete] = useState(null);

    const loadRooms = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (search) filters.search = search;
            if (filterStatus) filters.status = filterStatus;
            const data = await getRooms(filters);
            setRooms(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [search, filterStatus]);

    useEffect(() => {
        const timer = setTimeout(loadRooms, 250);
        return () => clearTimeout(timer);
    }, [loadRooms]);

    function openAddModal() {
        setForm(EMPTY_FORM);
        setFormError('');
        setEditingRoom({});
    }

    function openEditModal(room) {
        setForm({
            roomName: room.room_name,
            roomNumber: room.room_number,
            building: room.building,
            capacity: room.capacity,
            roomType: room.room_type,
            equipment: room.equipment || '',
            status: room.status
        });
        setFormError('');
        setEditingRoom(room);
    }

    function closeModal() {
        setEditingRoom(null);
        setFormError('');
    }

    async function submitForm() {
        setFormError('');
        setSaving(true);
        try {
            const payload = { ...form, capacity: Number(form.capacity) };
            if (editingRoom?.room_id) {
                await updateRoom(editingRoom.room_id, payload);
                showToast('Room updated successfully.');
            } else {
                await createRoom(payload);
                showToast('Room added successfully.');
            }
            closeModal();
            loadRooms();
        } catch (err) {
            const data = err.response?.data;
            if (data?.data?.requiresConfirmation) {
                // Capacity reduced below what upcoming events need — ask for confirmation instead of failing outright
                setCapacityWarning({ message: data.message, affectedEvents: data.data.affectedEvents, payload: { ...form, capacity: Number(form.capacity) } });
            } else {
                setFormError(getErrorMessage(err));
            }
        } finally {
            setSaving(false);
        }
    }

    async function confirmCapacityReduction() {
        setSaving(true);
        try {
            await updateRoom(editingRoom.room_id, { ...capacityWarning.payload, confirmCapacityChange: true });
            showToast('Room updated successfully.');
            setCapacityWarning(null);
            closeModal();
            loadRooms();
        } catch (err) {
            setFormError(getErrorMessage(err));
            setCapacityWarning(null);
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete() {
        try {
            const result = await deleteRoom(roomToDelete.room_id);
            showToast(result.message);
            setRoomToDelete(null);
            loadRooms();
        } catch (err) {
            showToast(getErrorMessage(err), 'error');
            setRoomToDelete(null);
        }
    }

    return (
        <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
                <h2 style={{ margin: 0 }}>Manage Rooms</h2>
                <button className="btn btn-primary" onClick={openAddModal}>+ Add Room</button>
            </div>

            <div className="filter-bar">
                <div className="form-group">
                    <label className="form-label">Search</label>
                    <input className="form-input" placeholder="Room number, name, building" value={search} onChange={(e) => setSearch(e.target.value)} />
                </div>
                <div className="form-group">
                    <label className="form-label">Status</label>
                    <select className="form-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                        <option value="">All statuses</option>
                        {ROOM_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading rooms..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={loadRooms} />}
                {status === 'success' && rooms.length === 0 && <EmptyState message="No rooms found." />}
                {status === 'success' && rooms.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr>
                                    <th>Room Number</th><th>Name</th><th>Building</th><th>Capacity</th>
                                    <th>Type</th><th>Status</th><th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rooms.map((room) => (
                                    <tr key={room.room_id}>
                                        <td data-label="Room Number"><strong>{room.room_number}</strong></td>
                                        <td data-label="Name">{room.room_name}</td>
                                        <td data-label="Building">{room.building}</td>
                                        <td data-label="Capacity">{room.capacity}</td>
                                        <td data-label="Type">{room.room_type}</td>
                                        <td data-label="Status"><StatusBadge status={room.status} /></td>
                                        <td data-label="Actions">
                                            <button className="btn btn-secondary btn-sm" style={{ marginRight: 6 }} onClick={() => openEditModal(room)}>Edit</button>
                                            <button className="btn btn-danger btn-sm" onClick={() => setRoomToDelete(room)}>Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {editingRoom !== null && (
                <Modal title={editingRoom.room_id ? 'Edit Room' : 'Add Room'} onClose={closeModal}>
                    {formError && <div className="alert alert-danger">{formError}</div>}
                    <div className="form-group">
                        <label className="form-label">Room Name</label>
                        <input className="form-input" value={form.roomName} onChange={(e) => setForm({ ...form, roomName: e.target.value })} required />
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Room Number</label>
                            <input className="form-input" value={form.roomNumber} onChange={(e) => setForm({ ...form, roomNumber: e.target.value })} required />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Building</label>
                            <input className="form-input" value={form.building} onChange={(e) => setForm({ ...form, building: e.target.value })} required />
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Capacity</label>
                            <input type="number" min="1" className="form-input" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} required />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Room Type</label>
                            <select className="form-select" value={form.roomType} onChange={(e) => setForm({ ...form, roomType: e.target.value })}>
                                {ROOM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Equipment</label>
                        <input className="form-input" placeholder="e.g. Projector, AC, WiFi" value={form.equipment} onChange={(e) => setForm({ ...form, equipment: e.target.value })} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Status</label>
                        <select className="form-select" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                            {ROOM_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <button className="btn btn-primary btn-block" disabled={saving} onClick={submitForm}>
                        {saving ? 'Saving...' : editingRoom.room_id ? 'Save Changes' : 'Add Room'}
                    </button>
                </Modal>
            )}

            {capacityWarning && (
                <ConfirmDialog
                    title="Capacity Warning"
                    danger
                    confirmLabel="Proceed Anyway"
                    message={
                        <div>
                            <p>{capacityWarning.message}</p>
                            <ul style={{ margin: 0, paddingLeft: 20 }}>
                                {capacityWarning.affectedEvents.map((e) => (
                                    <li key={e.event_id}>{e.event_name} — expects {e.expected_participants} participants</li>
                                ))}
                            </ul>
                        </div>
                    }
                    onConfirm={confirmCapacityReduction}
                    onCancel={() => setCapacityWarning(null)}
                />
            )}

            {roomToDelete && (
                <ConfirmDialog
                    title="Delete Room"
                    danger
                    confirmLabel="Delete"
                    message={`Are you sure you want to delete ${roomToDelete.room_number} — ${roomToDelete.room_name}? If it has booking history, it will be marked Inactive instead of deleted.`}
                    onConfirm={handleDelete}
                    onCancel={() => setRoomToDelete(null)}
                />
            )}
        </div>
    );
}

export default ManageRooms;
