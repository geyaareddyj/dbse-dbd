// pages/admin/ManageEvents.jsx
import { useState, useEffect, useCallback } from 'react';
import { getEvents, createEvent, updateEvent, deleteEvent, assignRoomToEvent, unassignRoom, EVENT_TYPES } from '../../services/eventService';
import { getRooms } from '../../services/roomService';
import { getErrorMessage } from '../../services/api';
import { useToast } from '../../context/ToastContext.jsx';
import Modal from '../../components/Modal.jsx';
import ConfirmDialog from '../../components/ConfirmDialog.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';
import { toDatetimeLocalValue } from '../../utils/dateUtils.js';

const EMPTY_FORM = { eventName: '', description: '', organizer: '', eventType: 'Workshop', startDate: '', endDate: '', expectedParticipants: '' };

function formatDateTime(dt) {
    return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function ManageEvents() {
    const { showToast } = useToast();
    const [events, setEvents] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');

    const [search, setSearch] = useState('');
    const [filterType, setFilterType] = useState('');

    const [editingEvent, setEditingEvent] = useState(null); // {} = adding, object = editing
    const [form, setForm] = useState(EMPTY_FORM);
    const [formError, setFormError] = useState('');
    const [saving, setSaving] = useState(false);

    const [eventToDelete, setEventToDelete] = useState(null);

    const [assigningEvent, setAssigningEvent] = useState(null); // event object, or null
    const [availableRooms, setAvailableRooms] = useState([]);
    const [selectedRoomId, setSelectedRoomId] = useState('');
    const [assignError, setAssignError] = useState('');
    const [assigning, setAssigning] = useState(false);

    const loadEvents = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (search) filters.search = search;
            if (filterType) filters.eventType = filterType;
            const data = await getEvents(filters);
            setEvents(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [search, filterType]);

    useEffect(() => {
        const timer = setTimeout(loadEvents, 250);
        return () => clearTimeout(timer);
    }, [loadEvents]);

    function openAddModal() {
        setForm(EMPTY_FORM);
        setFormError('');
        setEditingEvent({});
    }

    function openEditModal(event) {
        setForm({
            eventName: event.event_name,
            description: event.description || '',
            organizer: event.organizer,
            eventType: event.event_type,
            startDate: toDatetimeLocalValue(event.start_date),
            endDate: toDatetimeLocalValue(event.end_date),
            expectedParticipants: event.expected_participants
        });
        setFormError('');
        setEditingEvent(event);
    }

    function closeModal() {
        setEditingEvent(null);
        setFormError('');
    }

    async function submitForm() {
        setFormError('');
        setSaving(true);
        try {
            const payload = {
                ...form,
                startDate: form.startDate.replace('T', ' ') + ':00',
                endDate: form.endDate.replace('T', ' ') + ':00',
                expectedParticipants: Number(form.expectedParticipants) || 0
            };
            if (editingEvent?.event_id) {
                const result = await updateEvent(editingEvent.event_id, payload);
                showToast(result.message);
            } else {
                await createEvent(payload);
                showToast('Event created successfully.');
            }
            closeModal();
            loadEvents();
        } catch (err) {
            setFormError(getErrorMessage(err));
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete() {
        try {
            await deleteEvent(eventToDelete.event_id);
            showToast('Event deleted successfully.');
            setEventToDelete(null);
            loadEvents();
        } catch (err) {
            showToast(getErrorMessage(err), 'error');
            setEventToDelete(null);
        }
    }

    async function openAssignModal(event) {
        setAssigningEvent(event);
        setSelectedRoomId(event.room_id || '');
        setAssignError('');
        try {
            const rooms = await getRooms({ status: 'Available' });
            setAvailableRooms(rooms);
        } catch {
            setAvailableRooms([]);
        }
    }

    function closeAssignModal() {
        setAssigningEvent(null);
        setAssignError('');
    }

    async function submitAssignment() {
        setAssignError('');
        setAssigning(true);
        try {
            if (!selectedRoomId) {
                await unassignRoom(assigningEvent.event_id);
                showToast('Room unassigned from event.');
            } else {
                const result = await assignRoomToEvent(assigningEvent.event_id, Number(selectedRoomId));
                showToast(result.message);
            }
            closeAssignModal();
            loadEvents();
        } catch (err) {
            // These are the exact, specific messages from the backend's
            // status/capacity/conflict checks (Phase 6) — shown as-is.
            setAssignError(getErrorMessage(err));
        } finally {
            setAssigning(false);
        }
    }

    return (
        <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
                <h2 style={{ margin: 0 }}>Manage Events</h2>
                <button className="btn btn-primary" onClick={openAddModal}>+ Add Event</button>
            </div>

            <div className="filter-bar">
                <div className="form-group">
                    <label className="form-label">Search</label>
                    <input className="form-input" placeholder="Event name" value={search} onChange={(e) => setSearch(e.target.value)} />
                </div>
                <div className="form-group">
                    <label className="form-label">Type</label>
                    <select className="form-select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                        <option value="">All types</option>
                        {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading events..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={loadEvents} />}
                {status === 'success' && events.length === 0 && <EmptyState message="No events found." />}
                {status === 'success' && events.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr>
                                    <th>Event</th><th>Type</th><th>Start</th><th>Expected</th><th>Room</th><th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {events.map((event) => (
                                    <tr key={event.event_id}>
                                        <td data-label="Event"><strong>{event.event_name}</strong><div className="text-muted">{event.organizer}</div></td>
                                        <td data-label="Type">{event.event_type}</td>
                                        <td data-label="Start">{formatDateTime(event.start_date)}</td>
                                        <td data-label="Expected">{event.expected_participants}</td>
                                        <td data-label="Room">
                                            {event.room_number
                                                ? <span>{event.room_number} {event.expected_participants > event.room_capacity && <span className="badge badge-danger" style={{ marginLeft: 6 }}>Over capacity</span>}</span>
                                                : <span className="text-muted">Not assigned</span>}
                                        </td>
                                        <td data-label="Actions">
                                            <button className="btn btn-secondary btn-sm" style={{ marginRight: 6, marginBottom: 4 }} onClick={() => openEditModal(event)}>Edit</button>
                                            <button className="btn btn-secondary btn-sm" style={{ marginRight: 6, marginBottom: 4 }} onClick={() => openAssignModal(event)}>Assign Room</button>
                                            <button className="btn btn-danger btn-sm" onClick={() => setEventToDelete(event)}>Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {editingEvent !== null && (
                <Modal title={editingEvent.event_id ? 'Edit Event' : 'Add Event'} onClose={closeModal} width={560}>
                    {formError && <div className="alert alert-danger">{formError}</div>}
                    <div className="form-group">
                        <label className="form-label">Event Name</label>
                        <input className="form-input" value={form.eventName} onChange={(e) => setForm({ ...form, eventName: e.target.value })} required />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Description</label>
                        <textarea className="form-textarea" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Organizer</label>
                            <input className="form-input" value={form.organizer} onChange={(e) => setForm({ ...form, organizer: e.target.value })} required />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Event Type</label>
                            <select className="form-select" value={form.eventType} onChange={(e) => setForm({ ...form, eventType: e.target.value })}>
                                {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Start Date/Time</label>
                            <input type="datetime-local" className="form-input" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} required />
                        </div>
                        <div className="form-group">
                            <label className="form-label">End Date/Time</label>
                            <input type="datetime-local" className="form-input" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} required />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Expected Participants</label>
                        <input type="number" min="0" className="form-input" value={form.expectedParticipants} onChange={(e) => setForm({ ...form, expectedParticipants: e.target.value })} required />
                    </div>
                    <button className="btn btn-primary btn-block" disabled={saving} onClick={submitForm}>
                        {saving ? 'Saving...' : editingEvent.event_id ? 'Save Changes' : 'Create Event'}
                    </button>
                </Modal>
            )}

            {assigningEvent && (
                <Modal title={`Assign Room — ${assigningEvent.event_name}`} onClose={closeAssignModal}>
                    <p className="text-muted">Expects {assigningEvent.expected_participants} participants, {formatDateTime(assigningEvent.start_date)} – {formatDateTime(assigningEvent.end_date)}</p>
                    {assignError && <div className="alert alert-danger">{assignError}</div>}
                    <div className="form-group">
                        <label className="form-label">Room</label>
                        <select className="form-select" value={selectedRoomId} onChange={(e) => setSelectedRoomId(e.target.value)}>
                            <option value="">— No room (unassign) —</option>
                            {availableRooms.map((r) => (
                                <option key={r.room_id} value={r.room_id}>{r.room_number} — {r.room_name} (capacity {r.capacity})</option>
                            ))}
                        </select>
                    </div>
                    <button className="btn btn-primary btn-block" disabled={assigning} onClick={submitAssignment}>
                        {assigning ? 'Checking...' : 'Confirm'}
                    </button>
                </Modal>
            )}

            {eventToDelete && (
                <ConfirmDialog
                    title="Delete Event"
                    danger
                    confirmLabel="Delete"
                    message={`Delete "${eventToDelete.event_name}"? This will also remove its registrations, room schedule, and bookings.`}
                    onConfirm={handleDelete}
                    onCancel={() => setEventToDelete(null)}
                />
            )}
        </div>
    );
}

export default ManageEvents;
