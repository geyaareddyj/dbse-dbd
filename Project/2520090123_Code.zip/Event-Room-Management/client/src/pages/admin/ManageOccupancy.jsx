// pages/admin/ManageOccupancy.jsx
import { useState, useEffect, useCallback } from 'react';
import { getOccupancyRecords, createOccupancyRecord, updateOccupancyRecord } from '../../services/occupancyService';
import { getEvents } from '../../services/eventService';
import { getErrorMessage } from '../../services/api';
import { useToast } from '../../context/ToastContext.jsx';
import Modal from '../../components/Modal.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

function progressColor(label) {
    if (label === 'Normal') return 'success';
    if (label === 'High' || label === 'Near Capacity') return 'warning';
    return 'danger';
}

function OccupancyBar({ percentage, label }) {
    if (percentage === null) return <span className="text-muted">N/A</span>;
    return (
        <div>
            <div className="progress-track">
                <div className={`progress-fill ${progressColor(label)}`} style={{ width: `${Math.min(percentage, 100)}%` }} />
            </div>
            <div style={{ fontSize: 12, marginTop: 4 }}>{percentage}% — {label}</div>
        </div>
    );
}

function ManageOccupancy() {
    const { showToast } = useToast();
    const [records, setRecords] = useState([]);
    const [events, setEvents] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');

    const [showAddModal, setShowAddModal] = useState(false);
    const [addForm, setAddForm] = useState({ eventId: '', roomId: '', date: '', actualOccupancy: '' });
    const [addError, setAddError] = useState('');
    const [saving, setSaving] = useState(false);

    const [editingRecord, setEditingRecord] = useState(null);
    const [editValue, setEditValue] = useState('');

    const load = useCallback(async () => {
        setStatus('loading');
        try {
            const data = await getOccupancyRecords();
            setRecords(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, []);

    useEffect(() => {
        load();
        getEvents().then(setEvents).catch(() => setEvents([]));
    }, [load]);

    function openAddModal() {
        setAddForm({ eventId: '', roomId: '', date: '', actualOccupancy: '' });
        setAddError('');
        setShowAddModal(true);
    }

    async function submitAdd() {
        setAddError('');
        setSaving(true);
        try {
            const selectedEvent = events.find((e) => e.event_id === Number(addForm.eventId));
            await createOccupancyRecord({
                eventId: Number(addForm.eventId),
                roomId: selectedEvent.room_id,
                date: addForm.date,
                actualOccupancy: Number(addForm.actualOccupancy)
            });
            showToast('Occupancy record created.');
            setShowAddModal(false);
            load();
        } catch (err) {
            setAddError(getErrorMessage(err));
        } finally {
            setSaving(false);
        }
    }

    function openEditModal(record) {
        setEditingRecord(record);
        setEditValue(record.actual_occupancy);
    }

    async function submitEdit() {
        setSaving(true);
        try {
            await updateOccupancyRecord(editingRecord.occupancy_id, { actualOccupancy: Number(editValue) });
            showToast('Occupancy record updated.');
            setEditingRecord(null);
            load();
        } catch (err) {
            showToast(getErrorMessage(err), 'error');
        } finally {
            setSaving(false);
        }
    }

    return (
        <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
                <h2 style={{ margin: 0 }}>Occupancy Records</h2>
                <button className="btn btn-primary" onClick={openAddModal}>+ Add Record</button>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading occupancy records..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}
                {status === 'success' && records.length === 0 && <EmptyState message="No occupancy records yet." />}
                {status === 'success' && records.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr><th>Event</th><th>Room</th><th>Date</th><th>Expected</th><th>Registered</th><th>Actual</th><th>Occupancy</th><th></th></tr>
                            </thead>
                            <tbody>
                                {records.map((r) => (
                                    <tr key={r.occupancy_id}>
                                        <td data-label="Event">{r.event_name}</td>
                                        <td data-label="Room">{r.room_number}</td>
                                        <td data-label="Date">{new Date(r.date).toLocaleDateString()}</td>
                                        <td data-label="Expected">{r.expected_participants}</td>
                                        <td data-label="Registered">{r.registered_participants}</td>
                                        <td data-label="Actual">{r.actual_occupancy}</td>
                                        <td data-label="Occupancy" style={{ minWidth: 140 }}><OccupancyBar percentage={r.occupancyPercentage} label={r.occupancyLabel} /></td>
                                        <td data-label=""><button className="btn btn-secondary btn-sm" onClick={() => openEditModal(r)}>Update</button></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {showAddModal && (
                <Modal title="Add Occupancy Record" onClose={() => setShowAddModal(false)}>
                    {addError && <div className="alert alert-danger">{addError}</div>}
                    <div className="form-group">
                        <label className="form-label">Event</label>
                        <select className="form-select" value={addForm.eventId} onChange={(e) => setAddForm({ ...addForm, eventId: e.target.value })}>
                            <option value="">Select an event</option>
                            {events.map((e) => <option key={e.event_id} value={e.event_id}>{e.event_name} {e.room_number ? `(${e.room_number})` : '(no room)'}</option>)}
                        </select>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Date</label>
                        <input type="date" className="form-input" value={addForm.date} onChange={(e) => setAddForm({ ...addForm, date: e.target.value })} required />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Actual Occupancy (headcount)</label>
                        <input type="number" min="0" className="form-input" value={addForm.actualOccupancy} onChange={(e) => setAddForm({ ...addForm, actualOccupancy: e.target.value })} required />
                    </div>
                    <p className="text-muted">Expected and registered participant counts are filled in automatically from the event.</p>
                    <button className="btn btn-primary btn-block" disabled={saving} onClick={submitAdd}>
                        {saving ? 'Saving...' : 'Add Record'}
                    </button>
                </Modal>
            )}

            {editingRecord && (
                <Modal title={`Update Occupancy — ${editingRecord.event_name}`} onClose={() => setEditingRecord(null)}>
                    <div className="form-group">
                        <label className="form-label">Actual Occupancy (headcount)</label>
                        <input type="number" min="0" className="form-input" value={editValue} onChange={(e) => setEditValue(e.target.value)} />
                    </div>
                    <button className="btn btn-primary btn-block" disabled={saving} onClick={submitEdit}>
                        {saving ? 'Saving...' : 'Save'}
                    </button>
                </Modal>
            )}
        </div>
    );
}

export default ManageOccupancy;
