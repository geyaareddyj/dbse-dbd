// pages/admin/ManageBookings.jsx
import { useState, useEffect, useCallback } from 'react';
import { getBookings, cancelBooking, deleteBooking } from '../../services/bookingService';
import { getErrorMessage } from '../../services/api';
import { useToast } from '../../context/ToastContext.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import ConfirmDialog from '../../components/ConfirmDialog.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

function formatDateTime(dt) {
    return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function ManageBookings() {
    const { showToast } = useToast();
    const [bookings, setBookings] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [confirmAction, setConfirmAction] = useState(null); // { type: 'cancel'|'delete', booking }

    const loadBookings = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (filterStatus) filters.status = filterStatus;
            const data = await getBookings(filters);
            setBookings(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [filterStatus]);

    useEffect(() => { loadBookings(); }, [loadBookings]);

    async function handleConfirm() {
        const { type, booking } = confirmAction;
        try {
            if (type === 'cancel') {
                await cancelBooking(booking.booking_id);
                showToast('Booking cancelled successfully.');
            } else {
                await deleteBooking(booking.booking_id);
                showToast('Booking deleted successfully.');
            }
            setConfirmAction(null);
            loadBookings();
        } catch (err) {
            showToast(getErrorMessage(err), 'error');
            setConfirmAction(null);
        }
    }

    return (
        <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
                <h2 style={{ margin: 0 }}>Manage Bookings</h2>
            </div>

            <div className="filter-bar">
                <div className="form-group">
                    <label className="form-label">Status</label>
                    <select className="form-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                        <option value="">All statuses</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading bookings..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={loadBookings} />}
                {status === 'success' && bookings.length === 0 && <EmptyState message="No bookings found." />}
                {status === 'success' && bookings.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr><th>Event</th><th>Room</th><th>Time</th><th>Booked By</th><th>Status</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                                {bookings.map((b) => (
                                    <tr key={b.booking_id}>
                                        <td data-label="Event">{b.event_name}</td>
                                        <td data-label="Room">{b.room_number} — {b.room_name}</td>
                                        <td data-label="Time">{formatDateTime(b.start_time)} – {formatDateTime(b.end_time)}</td>
                                        <td data-label="Booked By">{b.booked_by}</td>
                                        <td data-label="Status"><StatusBadge status={b.status} /></td>
                                        <td data-label="Actions">
                                            {b.status === 'Confirmed' && (
                                                <button className="btn btn-secondary btn-sm" style={{ marginRight: 6 }} onClick={() => setConfirmAction({ type: 'cancel', booking: b })}>Cancel</button>
                                            )}
                                            <button className="btn btn-danger btn-sm" onClick={() => setConfirmAction({ type: 'delete', booking: b })}>Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {confirmAction && (
                <ConfirmDialog
                    title={confirmAction.type === 'cancel' ? 'Cancel Booking' : 'Delete Booking'}
                    danger
                    confirmLabel={confirmAction.type === 'cancel' ? 'Cancel Booking' : 'Delete'}
                    message={`Are you sure? This will free up ${confirmAction.booking.room_number} for "${confirmAction.booking.event_name}".`}
                    onConfirm={handleConfirm}
                    onCancel={() => setConfirmAction(null)}
                />
            )}
        </div>
    );
}

export default ManageBookings;
