// pages/admin/ManageRegistrations.jsx
import { useState, useEffect, useCallback } from 'react';
import { getAllRegistrations } from '../../services/registrationService';
import { getEvents } from '../../services/eventService';
import { getErrorMessage } from '../../services/api';
import StatusBadge from '../../components/StatusBadge.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

function ManageRegistrations() {
    const [registrations, setRegistrations] = useState([]);
    const [events, setEvents] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');
    const [filterEvent, setFilterEvent] = useState('');
    const [filterStatus, setFilterStatus] = useState('');

    useEffect(() => {
        getEvents().then(setEvents).catch(() => setEvents([]));
    }, []);

    const load = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (filterEvent) filters.eventId = filterEvent;
            if (filterStatus) filters.status = filterStatus;
            const data = await getAllRegistrations(filters);
            setRegistrations(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [filterEvent, filterStatus]);

    useEffect(() => { load(); }, [load]);

    return (
        <div>
            <h2 style={{ marginBottom: 16 }}>Registrations</h2>

            <div className="filter-bar">
                <div className="form-group">
                    <label className="form-label">Event</label>
                    <select className="form-select" value={filterEvent} onChange={(e) => setFilterEvent(e.target.value)}>
                        <option value="">All events</option>
                        {events.map((e) => <option key={e.event_id} value={e.event_id}>{e.event_name}</option>)}
                    </select>
                </div>
                <div className="form-group">
                    <label className="form-label">Status</label>
                    <select className="form-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                        <option value="">All statuses</option>
                        <option value="Registered">Registered</option>
                        <option value="Cancelled">Cancelled</option>
                        <option value="Attended">Attended</option>
                    </select>
                </div>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading registrations..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}
                {status === 'success' && registrations.length === 0 && <EmptyState message="No registrations found." />}
                {status === 'success' && registrations.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr><th>Student</th><th>Email</th><th>Event</th><th>Registered On</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                {registrations.map((r) => (
                                    <tr key={r.registration_id}>
                                        <td data-label="Student">{r.student_name}</td>
                                        <td data-label="Email">{r.student_email}</td>
                                        <td data-label="Event">{r.event_name}</td>
                                        <td data-label="Registered On">{new Date(r.registration_date).toLocaleDateString()}</td>
                                        <td data-label="Status"><StatusBadge status={r.status} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}

export default ManageRegistrations;
