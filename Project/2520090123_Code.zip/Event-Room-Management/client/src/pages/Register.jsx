// pages/Register.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth, getErrorMessage } from '../context/AuthContext.jsx';

function Register() {
    const { register } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ name: '', email: '', password: '', department: '' });
    const [error, setError] = useState('');
    const [submitting, setSubmitting] = useState(false);

    function updateField(field, value) {
        setForm((prev) => ({ ...prev, [field]: value }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        setSubmitting(true);
        try {
            await register(form);
            // Public registration always creates a student account (see backend Phase 3)
            navigate('/student');
        } catch (err) {
            setError(getErrorMessage(err));
        } finally {
            setSubmitting(false);
        }
    }

    return (
        <div className="narrow-container" style={{ paddingTop: 40 }}>
            <div className="card">
                <h2>Create your account</h2>
                <p>Register as a student to browse events and check room availability.</p>

                {error && <div className="alert alert-danger">{error}</div>}

                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className="form-label" htmlFor="name">Full name</label>
                        <input
                            id="name"
                            type="text"
                            className="form-input"
                            value={form.name}
                            onChange={(e) => updateField('name', e.target.value)}
                            required
                            autoFocus
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label" htmlFor="email">Email</label>
                        <input
                            id="email"
                            type="email"
                            className="form-input"
                            value={form.email}
                            onChange={(e) => updateField('email', e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label" htmlFor="department">Department</label>
                        <input
                            id="department"
                            type="text"
                            className="form-input"
                            placeholder="e.g. Computer Science"
                            value={form.department}
                            onChange={(e) => updateField('department', e.target.value)}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label" htmlFor="password">Password</label>
                        <input
                            id="password"
                            type="password"
                            className="form-input"
                            value={form.password}
                            onChange={(e) => updateField('password', e.target.value)}
                            required
                            minLength={6}
                        />
                    </div>
                    <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
                        {submitting ? 'Creating account...' : 'Register'}
                    </button>
                </form>

                <p style={{ marginTop: 16, textAlign: 'center' }}>
                    Already have an account? <Link to="/login">Log in</Link>
                </p>
            </div>
        </div>
    );
}

export default Register;
