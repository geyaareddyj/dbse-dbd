// pages/student/StudentRegistrations.jsx
import { useState, useEffect, useCallback } from 'react';
import { getMyRegistrations } from '../../services/registrationService';
import { getErrorMessage } from '../../services/api';
import StatusBadge from '../../components/StatusBadge.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

function formatDateTime(dt) {
    return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function StudentRegistrations() {
    const [registrations, setRegistrations] = useState([]);
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');

    const load = useCallback(async () => {
        setStatus('loading');
        try {
            const data = await getMyRegistrations();
            setRegistrations(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    return (
        <div>
            <h2>My Registrations</h2>

            {status === 'loading' && <LoadingState message="Loading your registrations..." />}
            {status === 'error' && <ErrorState message={errorMessage} onRetry={load} />}
            {status === 'success' && registrations.length === 0 && (
                <EmptyState message="You haven't registered for any events yet. Browse the Events tab to get started." />
            )}

            {status === 'success' && registrations.length > 0 && (
                <div className="card">
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr><th>Event</th><th>Type</th><th>When</th><th>Room</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                {registrations.map((r) => (
                                    <tr key={r.registration_id}>
                                        <td data-label="Event"><strong>{r.event_name}</strong></td>
                                        <td data-label="Type">{r.event_type}</td>
                                        <td data-label="When">{formatDateTime(r.start_date)}</td>
                                        <td data-label="Room">{r.room_number || <span className="text-muted">Not assigned</span>}</td>
                                        <td data-label="Status"><StatusBadge status={r.status} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}

export default StudentRegistrations;
