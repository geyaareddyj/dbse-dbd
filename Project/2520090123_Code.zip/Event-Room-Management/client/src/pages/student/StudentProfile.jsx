// pages/student/StudentProfile.jsx
import { useAuth } from '../../context/AuthContext.jsx';

function StudentProfile() {
    const { user } = useAuth();

    return (
        <div>
            <h2>Profile</h2>
            <div className="card" style={{ maxWidth: 420 }}>
                <div className="form-group">
                    <label className="form-label">Name</label>
                    <div>{user?.name}</div>
                </div>
                <div className="form-group">
                    <label className="form-label">Email</label>
                    <div>{user?.email}</div>
                </div>
                <div className="form-group">
                    <label className="form-label">Department</label>
                    <div>{user?.department || '—'}</div>
                </div>
                <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Role</label>
                    <div style={{ textTransform: 'capitalize' }}>{user?.role}</div>
                </div>
            </div>
        </div>
    );
}

export default StudentProfile;
