// pages/student/StudentDashboardHome.jsx
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { getEvents } from '../../services/eventService';
import { getMyRegistrations } from '../../services/registrationService';
import { getErrorMessage } from '../../services/api';
import { LoadingState, ErrorState } from '../../components/DataStates.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';

function formatDateTime(dt) {
    return new Date(dt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function StudentDashboardHome() {
    const { user } = useAuth();
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');
    const [upcomingEvents, setUpcomingEvents] = useState([]);
    const [myRegistrations, setMyRegistrations] = useState([]);

    useEffect(() => {
        async function load() {
            setStatus('loading');
            try {
                const [events, registrations] = await Promise.all([getEvents(), getMyRegistrations()]);
                const now = new Date();
                const upcoming = events
                    .filter((e) => new Date(e.start_date) > now)
                    .sort((a, b) => new Date(a.start_date) - new Date(b.start_date))
                    .slice(0, 4);
                setUpcomingEvents(upcoming);
                setMyRegistrations(registrations.filter((r) => r.status !== 'Cancelled'));
                setStatus('success');
            } catch (err) {
                setErrorMessage(getErrorMessage(err));
                setStatus('error');
            }
        }
        load();
    }, []);

    if (status === 'loading') return <LoadingState message="Loading dashboard..." />;
    if (status === 'error') return <ErrorState message={errorMessage} />;

    return (
        <div>
            <h2>Welcome, {user?.name}</h2>

            <div className="card-grid" style={{ marginBottom: 24 }}>
                <div className="card stat-card">
                    <div className="stat-value">{upcomingEvents.length}</div>
                    <div className="stat-label">Upcoming Events</div>
                </div>
                <div className="card stat-card">
                    <div className="stat-value">{myRegistrations.length}</div>
                    <div className="stat-label">My Active Registrations</div>
                </div>
            </div>

            <div className="card" style={{ marginBottom: 20 }}>
                <div className="flex-between">
                    <h3 style={{ margin: 0 }}>Upcoming Events</h3>
                    <Link to="/student/events" className="btn btn-secondary btn-sm">Browse all</Link>
                </div>
                {upcomingEvents.length === 0 && <p className="text-muted" style={{ marginTop: 12 }}>No upcoming events right now.</p>}
                {upcomingEvents.map((e) => (
                    <div key={e.event_id} style={{ padding: '10px 0', borderBottom: '1px solid var(--color-border)' }}>
                        <strong>{e.event_name}</strong>
                        <div className="text-muted">{formatDateTime(e.start_date)} · {e.room_number || 'Room not assigned'}</div>
                    </div>
                ))}
            </div>

            <div className="card">
                <div className="flex-between">
                    <h3 style={{ margin: 0 }}>My Registrations</h3>
                    <Link to="/student/registrations" className="btn btn-secondary btn-sm">View all</Link>
                </div>
                {myRegistrations.length === 0 && <p className="text-muted" style={{ marginTop: 12 }}>You haven't registered for anything yet.</p>}
                {myRegistrations.slice(0, 4).map((r) => (
                    <div key={r.registration_id} className="flex-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--color-border)' }}>
                        <span>{r.event_name}</span>
                        <StatusBadge status={r.status} />
                    </div>
                ))}
            </div>
        </div>
    );
}

export default StudentDashboardHome;
