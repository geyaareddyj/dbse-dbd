// pages/student/StudentEvents.jsx
import { useState, useEffect, useCallback } from 'react';
import { getEvents } from '../../services/eventService';
import { getMyRegistrations, registerForEvent } from '../../services/registrationService';
import { getErrorMessage } from '../../services/api';
import { useToast } from '../../context/ToastContext.jsx';
import Modal from '../../components/Modal.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';
import { EVENT_TYPES } from '../../services/eventService';

function formatDate(dt) {
    return new Date(dt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' });
}
function formatTimeRange(start, end) {
    const opts = { hour: '2-digit', minute: '2-digit' };
    return `${new Date(start).toLocaleTimeString('en-US', opts)} – ${new Date(end).toLocaleTimeString('en-US', opts)}`;
}

function StudentEvents() {
    const { showToast } = useToast();
    const [events, setEvents] = useState([]);
    const [registeredEventIds, setRegisteredEventIds] = useState(new Set());
    const [status, setStatus] = useState('loading');
    const [errorMessage, setErrorMessage] = useState('');

    const [search, setSearch] = useState('');
    const [filterType, setFilterType] = useState('');

    const [detailsEvent, setDetailsEvent] = useState(null);
    const [registeringId, setRegisteringId] = useState(null);

    const loadEvents = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (search) filters.search = search;
            if (filterType) filters.eventType = filterType;
            const [eventData, myRegs] = await Promise.all([getEvents(filters), getMyRegistrations()]);
            setEvents(eventData);
            setRegisteredEventIds(new Set(myRegs.filter((r) => r.status !== 'Cancelled').map((r) => r.event_id)));
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [search, filterType]);

    useEffect(() => {
        const timer = setTimeout(loadEvents, 250);
        return () => clearTimeout(timer);
    }, [loadEvents]);

    async function handleRegister(event) {
        setRegisteringId(event.event_id);
        try {
            const result = await registerForEvent(event.event_id);
            showToast(result.message);
            setRegisteredEventIds((prev) => new Set(prev).add(event.event_id));
            setDetailsEvent(null);
        } catch (err) {
            showToast(getErrorMessage(err), 'error');
        } finally {
            setRegisteringId(null);
        }
    }

    const isPastEvent = (event) => new Date(event.end_date) < new Date();

    return (
        <div>
            <h2>Events</h2>

            <div className="filter-bar">
                <div className="form-group">
                    <label className="form-label">Search</label>
                    <input className="form-input" placeholder="Event name" value={search} onChange={(e) => setSearch(e.target.value)} />
                </div>
                <div className="form-group">
                    <label className="form-label">Type</label>
                    <select className="form-select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                        <option value="">All types</option>
                        {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
            </div>

            {status === 'loading' && <LoadingState message="Loading events..." />}
            {status === 'error' && <ErrorState message={errorMessage} onRetry={loadEvents} />}
            {status === 'success' && events.length === 0 && <EmptyState message="No events match your search." />}

            {status === 'success' && events.length > 0 && (
                <div className="card-grid">
                    {events.map((event) => {
                        const registered = registeredEventIds.has(event.event_id);
                        const past = isPastEvent(event);
                        return (
                            <div key={event.event_id} className="card">
                                <h3 style={{ marginBottom: 2 }}>{event.event_name}</h3>
                                <span className="badge badge-neutral" style={{ marginBottom: 8 }}>{event.event_type}</span>
                                <p style={{ margin: '8px 0 2px 0' }}>{formatDate(event.start_date)}</p>
                                <p style={{ margin: 0 }}>{formatTimeRange(event.start_date, event.end_date)}</p>
                                <p style={{ marginTop: 10 }}>
                                    Expected: {event.expected_participants}<br />
                                    Room: {event.room_number || 'Not assigned'}
                                    {event.room_capacity && <> (capacity {event.room_capacity})</>}
                                </p>
                                <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                                    <button className="btn btn-secondary btn-sm" onClick={() => setDetailsEvent(event)}>View Details</button>
                                    {registered ? (
                                        <span className="badge badge-success" style={{ alignSelf: 'center' }}>Registered</span>
                                    ) : past ? (
                                        <span className="badge badge-neutral" style={{ alignSelf: 'center' }}>Event ended</span>
                                    ) : (
                                        <button
                                            className="btn btn-primary btn-sm"
                                            disabled={registeringId === event.event_id}
                                            onClick={() => handleRegister(event)}
                                        >
                                            {registeringId === event.event_id ? 'Registering...' : 'Register'}
                                        </button>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {detailsEvent && (
                <Modal title={detailsEvent.event_name} onClose={() => setDetailsEvent(null)}>
                    <p><strong>Type:</strong> {detailsEvent.event_type}</p>
                    <p><strong>Organizer:</strong> {detailsEvent.organizer}</p>
                    <p><strong>When:</strong> {formatDate(detailsEvent.start_date)}, {formatTimeRange(detailsEvent.start_date, detailsEvent.end_date)}</p>
                    <p><strong>Room:</strong> {detailsEvent.room_number ? `${detailsEvent.room_number} — ${detailsEvent.room_name}` : 'Not assigned yet'}</p>
                    <p><strong>Expected Participants:</strong> {detailsEvent.expected_participants}</p>
                    {detailsEvent.description && <p>{detailsEvent.description}</p>}

                    {registeredEventIds.has(detailsEvent.event_id) ? (
                        <div className="alert alert-success">You're registered for this event.</div>
                    ) : isPastEvent(detailsEvent) ? (
                        <div className="alert alert-info">This event has already ended.</div>
                    ) : (
                        <button
                            className="btn btn-primary btn-block"
                            disabled={registeringId === detailsEvent.event_id}
                            onClick={() => handleRegister(detailsEvent)}
                        >
                            {registeringId === detailsEvent.event_id ? 'Registering...' : 'Register for this event'}
                        </button>
                    )}
                </Modal>
            )}
        </div>
    );
}

export default StudentEvents;
