// pages/rooms/RoomAvailability.jsx
import { useState } from 'react';
import { checkRoomAvailability } from '../../services/roomService';
import { getErrorMessage } from '../../services/api';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';
import { todayLocalISODate } from '../../utils/dateUtils.js';

function RoomAvailability() {
    const [date, setDate] = useState(todayLocalISODate());
    const [startTime, setStartTime] = useState('10:00');
    const [endTime, setEndTime] = useState('12:00');
    const [minCapacity, setMinCapacity] = useState('');

    const [status, setStatus] = useState('idle'); // idle | loading | success | error
    const [errorMessage, setErrorMessage] = useState('');
    const [result, setResult] = useState(null);

    async function handleSubmit(e) {
        e.preventDefault();

        if (startTime >= endTime) {
            setStatus('error');
            setErrorMessage('Start time must be before end time.');
            return;
        }

        setStatus('loading');
        try {
            const params = { date, startTime, endTime };
            if (minCapacity) params.minCapacity = minCapacity;
            const data = await checkRoomAvailability(params);
            setResult(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }

    return (
        <div>
            <h2>Room Availability</h2>
            <p>Select a date and time range to see which rooms are free and which are already booked.</p>

            <div className="card" style={{ marginBottom: 20 }}>
                <form onSubmit={handleSubmit}>
                    <div className="form-row">
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label">Date</label>
                            <input
                                type="date"
                                className="form-input"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label">Start time</label>
                            <input
                                type="time"
                                className="form-input"
                                value={startTime}
                                onChange={(e) => setStartTime(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label">End time</label>
                            <input
                                type="time"
                                className="form-input"
                                value={endTime}
                                onChange={(e) => setEndTime(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group" style={{ marginBottom: 0 }}>
                            <label className="form-label">Required capacity (optional)</label>
                            <input
                                type="number"
                                min="0"
                                className="form-input"
                                placeholder="Any"
                                value={minCapacity}
                                onChange={(e) => setMinCapacity(e.target.value)}
                            />
                        </div>
                    </div>
                    <div style={{ marginTop: 16 }}>
                        <button type="submit" className="btn btn-primary" disabled={status === 'loading'}>
                            {status === 'loading' ? 'Checking...' : 'Check Availability'}
                        </button>
                    </div>
                </form>
            </div>

            {status === 'idle' && (
                <EmptyState message="Choose a date and time above, then check availability to see results here." />
            )}
            {status === 'loading' && <LoadingState message="Checking room availability..." />}
            {status === 'error' && <ErrorState message={errorMessage} />}

            {status === 'success' && result && (
                <div className="form-row" style={{ alignItems: 'stretch' }}>
                    <div className="card" style={{ flex: 1, minWidth: 280 }}>
                        <h3 style={{ color: 'var(--color-success)' }}>✓ Available ({result.available.length})</h3>
                        {result.available.length === 0 && <p className="text-muted">No rooms are available for this slot.</p>}
                        {result.available.map((room) => (
                            <div key={room.room_id} className="card" style={{ marginBottom: 10, borderLeft: '4px solid var(--color-success)' }}>
                                <strong>{room.room_number} — {room.room_name}</strong>
                                <p style={{ margin: '4px 0 0 0' }}>
                                    {room.building} · Capacity {room.capacity} · {room.room_type}
                                    {room.equipment && <> · {room.equipment}</>}
                                </p>
                            </div>
                        ))}
                    </div>

                    <div className="card" style={{ flex: 1, minWidth: 280 }}>
                        <h3 style={{ color: 'var(--color-danger)' }}>✗ Unavailable ({result.unavailable.length})</h3>
                        {result.unavailable.length === 0 && <p className="text-muted">Every room is free for this slot.</p>}
                        {result.unavailable.map((room) => (
                            <div key={room.room_id} className="card" style={{ marginBottom: 10, borderLeft: '4px solid var(--color-danger)' }}>
                                <strong>{room.room_number} — {room.room_name}</strong>
                                <p style={{ margin: '4px 0 0 0' }}>{room.reason}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default RoomAvailability;
