// pages/rooms/RoomsList.jsx
import { useState, useEffect, useCallback } from 'react';
import { getRooms, ROOM_TYPES, ROOM_STATUSES } from '../../services/roomService';
import { getErrorMessage } from '../../services/api';
import StatusBadge from '../../components/StatusBadge.jsx';
import { LoadingState, EmptyState, ErrorState } from '../../components/DataStates.jsx';

function RoomsList() {
    const [rooms, setRooms] = useState([]);
    const [status, setStatus] = useState('idle'); // idle | loading | success | error
    const [errorMessage, setErrorMessage] = useState('');

    const [search, setSearch] = useState('');
    const [roomType, setRoomType] = useState('');
    const [roomStatus, setRoomStatus] = useState('');
    const [minCapacity, setMinCapacity] = useState('');

    const loadRooms = useCallback(async () => {
        setStatus('loading');
        try {
            const filters = {};
            if (search) filters.search = search;
            if (roomType) filters.roomType = roomType;
            if (roomStatus) filters.status = roomStatus;
            if (minCapacity) filters.minCapacity = minCapacity;

            const data = await getRooms(filters);
            setRooms(data);
            setStatus('success');
        } catch (err) {
            setErrorMessage(getErrorMessage(err));
            setStatus('error');
        }
    }, [search, roomType, roomStatus, minCapacity]);

    // Debounce search-as-you-type slightly, but filters apply immediately
    useEffect(() => {
        const timer = setTimeout(loadRooms, 300);
        return () => clearTimeout(timer);
    }, [loadRooms]);

    return (
        <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
                <h2 style={{ margin: 0 }}>Rooms</h2>
            </div>

            <div className="card" style={{ marginBottom: 16 }}>
                <div className="form-row">
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label">Search</label>
                        <input
                            className="form-input"
                            placeholder="Room number, name, or building"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label">Type</label>
                        <select className="form-select" value={roomType} onChange={(e) => setRoomType(e.target.value)}>
                            <option value="">All types</option>
                            {ROOM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                        </select>
                    </div>
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label">Status</label>
                        <select className="form-select" value={roomStatus} onChange={(e) => setRoomStatus(e.target.value)}>
                            <option value="">All statuses</option>
                            {ROOM_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <div className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label">Min. capacity</label>
                        <input
                            type="number"
                            min="0"
                            className="form-input"
                            placeholder="Any"
                            value={minCapacity}
                            onChange={(e) => setMinCapacity(e.target.value)}
                        />
                    </div>
                </div>
            </div>

            <div className="card">
                {status === 'loading' && <LoadingState message="Loading rooms..." />}
                {status === 'error' && <ErrorState message={errorMessage} onRetry={loadRooms} />}
                {status === 'success' && rooms.length === 0 && (
                    <EmptyState message="No rooms match your filters." />
                )}
                {status === 'success' && rooms.length > 0 && (
                    <div className="table-wrap">
                        <table className="responsive-table">
                            <thead>
                                <tr>
                                    <th>Room Number</th>
                                    <th>Room Name</th>
                                    <th>Building</th>
                                    <th>Capacity</th>
                                    <th>Type</th>
                                    <th>Equipment</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rooms.map((room) => (
                                    <tr key={room.room_id}>
                                        <td data-label="Room Number"><strong>{room.room_number}</strong></td>
                                        <td data-label="Room Name">{room.room_name}</td>
                                        <td data-label="Building">{room.building}</td>
                                        <td data-label="Capacity">{room.capacity}</td>
                                        <td data-label="Type">{room.room_type}</td>
                                        <td data-label="Equipment">{room.equipment || '—'}</td>
                                        <td data-label="Status"><StatusBadge status={room.status} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}

export default RoomsList;
