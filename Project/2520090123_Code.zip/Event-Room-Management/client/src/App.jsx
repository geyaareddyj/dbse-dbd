// App.jsx
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import NotFound from './pages/NotFound.jsx';

import StudentLayout from './components/layout/StudentLayout.jsx';
import StudentDashboardHome from './pages/student/StudentDashboardHome.jsx';
import StudentEvents from './pages/student/StudentEvents.jsx';
import StudentRegistrations from './pages/student/StudentRegistrations.jsx';
import StudentProfile from './pages/student/StudentProfile.jsx';

import AdminLayout from './components/layout/AdminLayout.jsx';
import AdminDashboardHome from './pages/admin/AdminDashboardHome.jsx';

import RoomsList from './pages/rooms/RoomsList.jsx';
import RoomAvailability from './pages/rooms/RoomAvailability.jsx';
import ManageRooms from './pages/admin/ManageRooms.jsx';
import ManageEvents from './pages/admin/ManageEvents.jsx';
import ManageBookings from './pages/admin/ManageBookings.jsx';
import ManageRegistrations from './pages/admin/ManageRegistrations.jsx';
import ManageOccupancy from './pages/admin/ManageOccupancy.jsx';

function App() {
    const { user, loading } = useAuth();

    if (loading) {
        return <div className="loading-state">Loading...</div>;
    }

    return (
        <Routes>
            <Route path="/login" element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/student'} /> : <Login />} />
            <Route path="/register" element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/student'} /> : <Register />} />

            {/* ---------- Student area ---------- */}
            <Route path="/student" element={<ProtectedRoute role="student"><StudentLayout /></ProtectedRoute>}>
                <Route index element={<StudentDashboardHome />} />
                <Route path="rooms" element={<RoomsList />} />
                <Route path="rooms/availability" element={<RoomAvailability />} />
                <Route path="events" element={<StudentEvents />} />
                <Route path="registrations" element={<StudentRegistrations />} />
                <Route path="profile" element={<StudentProfile />} />
            </Route>

            {/* ---------- Admin area ---------- */}
            <Route path="/admin" element={<ProtectedRoute role="admin"><AdminLayout /></ProtectedRoute>}>
                <Route index element={<AdminDashboardHome />} />
                <Route path="rooms" element={<ManageRooms />} />
                <Route path="rooms/availability" element={<RoomAvailability />} />
                <Route path="events" element={<ManageEvents />} />
                <Route path="bookings" element={<ManageBookings />} />
                <Route path="registrations" element={<ManageRegistrations />} />
                <Route path="occupancy" element={<ManageOccupancy />} />
            </Route>

            <Route path="/" element={<Navigate to={user ? (user.role === 'admin' ? '/admin' : '/student') : '/login'} />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
    );
}

export default App;
