// services/api.js
// A single, central axios instance. Every API call in the app goes through
// this file instead of scattering axios.get/post calls (and base URLs)
// across components — the "no hard-coded API URLs" rule from the spec.
import axios from 'axios';

const api = axios.create({
    baseURL: '/api', // proxied to the Express server in dev (see vite.config.js)
    headers: { 'Content-Type': 'application/json' }
});

// Attach the JWT (if we have one) to every outgoing request
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// If the token is invalid/expired, the backend returns 401 — log the user
// out automatically so they aren't stuck seeing broken data.
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            if (window.location.pathname !== '/login') {
                window.location.href = '/login';
            }
        }
        return Promise.reject(error);
    }
);

// Small helper so components don't need to repeat error.response.data.message everywhere
export function getErrorMessage(err) {
    return err.response?.data?.message || 'Something went wrong. Please try again.';
}

export default api;
