// services/eventService.js
import api from './api';

export async function getEvents(filters = {}) {
    const res = await api.get('/events', { params: filters });
    return res.data.data;
}

export async function getEventById(eventId) {
    const res = await api.get(`/events/${eventId}`);
    return res.data.data;
}

export async function createEvent(event) {
    const res = await api.post('/events', event);
    return res.data;
}

export async function updateEvent(eventId, event) {
    const res = await api.put(`/events/${eventId}`, event);
    return res.data;
}

export async function deleteEvent(eventId) {
    const res = await api.delete(`/events/${eventId}`);
    return res.data;
}

// Throws on failure (ROOM_INACTIVE / CAPACITY_EXCEEDED / SCHEDULE_CONFLICT) —
// callers should catch and show err.response.data.message directly, since
// the backend already writes these as clear, specific sentences.
export async function assignRoomToEvent(eventId, roomId) {
    const res = await api.put(`/events/${eventId}/assign-room`, { roomId });
    return res.data;
}

export async function unassignRoom(eventId) {
    const res = await api.put(`/events/${eventId}/assign-room`, { roomId: null });
    return res.data;
}

export const EVENT_TYPES = ['Workshop', 'Seminar', 'Hackathon', 'Competition', 'Club Event', 'Meeting', 'Other'];
