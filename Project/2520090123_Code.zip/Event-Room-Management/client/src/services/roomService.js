// services/roomService.js
import api from './api';

export async function getRooms(filters = {}) {
    const res = await api.get('/rooms', { params: filters });
    return res.data.data;
}

export async function getRoomById(roomId) {
    const res = await api.get(`/rooms/${roomId}`);
    return res.data.data;
}

export async function checkRoomAvailability(params) {
    const res = await api.get('/rooms/available', { params });
    return res.data.data;
}

export async function createRoom(room) {
    const res = await api.post('/rooms', room);
    return res.data;
}

export async function updateRoom(roomId, room) {
    // Note: a capacity-reduction warning comes back as an HTTP 409, which axios
    // treats as a rejected promise — callers should catch it and inspect
    // err.response.data.data.requiresConfirmation (see Phase 4 backend).
    const res = await api.put(`/rooms/${roomId}`, room);
    return res.data;
}

export async function deleteRoom(roomId) {
    const res = await api.delete(`/rooms/${roomId}`);
    return res.data;
}

export const ROOM_TYPES = ['Classroom', 'Lab', 'Seminar Hall', 'Conference Room', 'Auditorium'];
export const ROOM_STATUSES = ['Available', 'Maintenance', 'Inactive'];
