// services/occupancyService.js
import api from './api';

export async function getOccupancyRecords(filters = {}) {
    const res = await api.get('/occupancy', { params: filters });
    return res.data.data;
}

export async function createOccupancyRecord(record) {
    const res = await api.post('/occupancy', record);
    return res.data;
}

export async function updateOccupancyRecord(occupancyId, record) {
    const res = await api.put(`/occupancy/${occupancyId}`, record);
    return res.data;
}
