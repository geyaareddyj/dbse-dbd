// services/bookingService.js
import api from './api';

export async function getBookings(filters = {}) {
    const res = await api.get('/bookings', { params: filters });
    return res.data.data;
}

export async function cancelBooking(bookingId) {
    const res = await api.put(`/bookings/${bookingId}`, { status: 'Cancelled' });
    return res.data;
}

export async function deleteBooking(bookingId) {
    const res = await api.delete(`/bookings/${bookingId}`);
    return res.data;
}
