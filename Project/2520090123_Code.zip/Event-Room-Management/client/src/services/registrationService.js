// services/registrationService.js
import api from './api';

export async function getAllRegistrations(filters = {}) {
    const res = await api.get('/registrations', { params: filters });
    return res.data.data;
}

export async function getRegistrationsForEvent(eventId) {
    const res = await api.get(`/registrations/event/${eventId}`);
    return res.data.data;
}

export async function getMyRegistrations() {
    const res = await api.get('/registrations/my');
    return res.data.data;
}

export async function registerForEvent(eventId, notes) {
    const res = await api.post('/registrations', { eventId, notes });
    return res.data;
}
