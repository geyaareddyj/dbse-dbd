// components/ConfirmDialog.jsx
import Modal from './Modal.jsx';

// A confirm/cancel dialog for destructive or warning actions (delete room,
// reduce capacity below what upcoming events need, etc). `danger` swaps the
// confirm button to red for genuinely destructive actions.
function ConfirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, onConfirm, onCancel }) {
    return (
        <Modal title={title} onClose={onCancel} width={420}>
            <div>{message}</div>
            <div className="flex-between" style={{ marginTop: 20, justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={onCancel}>Cancel</button>
                <button className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`} onClick={onConfirm}>
                    {confirmLabel}
                </button>
            </div>
        </Modal>
    );
}

export default ConfirmDialog;
