// components/layout/StudentLayout.jsx
import { Outlet } from 'react-router-dom';
import Navbar from '../Navbar.jsx';
import StudentTopNav from './StudentTopNav.jsx';

function StudentLayout() {
    return (
        <div className="app-shell">
            <Navbar />
            <StudentTopNav />
            <div className="page-container">
                <Outlet />
            </div>
        </div>
    );
}

export default StudentLayout;
