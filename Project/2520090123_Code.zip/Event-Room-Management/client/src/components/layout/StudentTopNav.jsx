// components/layout/StudentTopNav.jsx
import { NavLink } from 'react-router-dom';

const STUDENT_LINKS = [
    { to: '/student', label: 'Dashboard', end: true },
    { to: '/student/events', label: 'Events' },
    { to: '/student/registrations', label: 'My Registrations' },
    { to: '/student/rooms/availability', label: 'Room Availability' },
    { to: '/student/profile', label: 'Profile' }
];

function StudentTopNav() {
    return (
        <nav className="student-tabnav">
            {STUDENT_LINKS.map((link) => (
                <NavLink
                    key={link.to}
                    to={link.to}
                    end={link.end}
                    className={({ isActive }) => `student-tab${isActive ? ' active' : ''}`}
                >
                    {link.label}
                </NavLink>
            ))}
        </nav>
    );
}

export default StudentTopNav;
