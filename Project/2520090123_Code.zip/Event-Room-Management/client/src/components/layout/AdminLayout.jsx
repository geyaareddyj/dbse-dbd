// components/layout/AdminLayout.jsx
import { Outlet } from 'react-router-dom';
import Navbar from '../Navbar.jsx';
import Sidebar from './Sidebar.jsx';

function AdminLayout() {
    return (
        <div className="app-shell">
            <Navbar />
            <div className="with-sidebar">
                <Sidebar />
                <div className="sidebar-content">
                    <Outlet />
                </div>
            </div>
        </div>
    );
}

export default AdminLayout;
