// components/layout/Sidebar.jsx
import { NavLink } from 'react-router-dom';

const ADMIN_LINKS = [
    { to: '/admin', label: 'Dashboard', end: true },
    { to: '/admin/events', label: 'Events' },
    { to: '/admin/rooms', label: 'Rooms' },
    { to: '/admin/rooms/availability', label: 'Room Availability' },
    { to: '/admin/bookings', label: 'Bookings' },
    { to: '/admin/registrations', label: 'Registrations' },
    { to: '/admin/occupancy', label: 'Occupancy' }
];

function Sidebar() {
    return (
        <nav className="sidebar">
            {ADMIN_LINKS.map((link) => (
                <NavLink
                    key={link.to}
                    to={link.to}
                    end={link.end}
                    className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
                >
                    {link.label}
                </NavLink>
            ))}
        </nav>
    );
}

export default Sidebar;
