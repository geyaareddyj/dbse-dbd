// components/Modal.jsx
import { useEffect } from 'react';

// One shared modal shell. Every "Add Room", "Edit Event", "Assign Room" form
// renders its content inside this, so they all look and behave consistently
// instead of each page reinventing its own popup.
function Modal({ title, onClose, children, width = 480 }) {
    // Let Escape close the modal, like users expect
    useEffect(() => {
        function handleKey(e) {
            if (e.key === 'Escape') onClose();
        }
        document.addEventListener('keydown', handleKey);
        return () => document.removeEventListener('keydown', handleKey);
    }, [onClose]);

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-box" style={{ maxWidth: width }} onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <h3 style={{ margin: 0 }}>{title}</h3>
                    <button className="modal-close" onClick={onClose} aria-label="Close">×</button>
                </div>
                <div className="modal-body">{children}</div>
            </div>
        </div>
    );
}

export default Modal;
