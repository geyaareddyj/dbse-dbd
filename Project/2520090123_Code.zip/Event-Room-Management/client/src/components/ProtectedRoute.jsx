// components/ProtectedRoute.jsx
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

// Wrap any route element with this to require login, and optionally a
// specific role. Usage: <ProtectedRoute role="admin"><AdminPage /></ProtectedRoute>
function ProtectedRoute({ children, role }) {
    const { user, loading } = useAuth();

    if (loading) {
        return <div className="loading-state">Loading...</div>;
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (role && user.role !== role) {
        // Logged in, but wrong role — send them to their own dashboard instead
        return <Navigate to={user.role === 'admin' ? '/admin' : '/student'} replace />;
    }

    return children;
}

export default ProtectedRoute;
