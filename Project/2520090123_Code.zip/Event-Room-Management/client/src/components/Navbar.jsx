// components/Navbar.jsx
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

function Navbar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    function handleLogout() {
        logout();
        navigate('/login');
    }

    return (
        <header className="navbar">
            <div className="navbar-brand">Campus<span>Rooms</span></div>
            <div className="navbar-links">
                {user && (
                    <>
                        <span className="navbar-user">{user.name} ({user.role})</span>
                        <button className="btn btn-secondary btn-sm" onClick={handleLogout}>Logout</button>
                    </>
                )}
            </div>
        </header>
    );
}

export default Navbar;
