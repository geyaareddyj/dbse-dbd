// components/StatusBadge.jsx
// One shared badge component for every status shown across the app:
// room status, registration status, booking status, occupancy labels.
// Keeping the color mapping in one place means a status always looks
// the same everywhere the user sees it.
const COLOR_MAP = {
    // Room statuses
    Available: 'success',
    Maintenance: 'warning',
    Inactive: 'neutral',
    // Registration / booking statuses
    Registered: 'success',
    Confirmed: 'success',
    Cancelled: 'danger',
    Attended: 'success',
    Scheduled: 'success',
    Completed: 'neutral',
    // Occupancy labels
    Normal: 'success',
    High: 'warning',
    'Near Capacity': 'warning',
    'Over Capacity': 'danger'
};

function StatusBadge({ status }) {
    const color = COLOR_MAP[status] || 'neutral';
    return <span className={`badge badge-${color}`}>{status}</span>;
}

export default StatusBadge;
