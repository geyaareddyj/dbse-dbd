// components/DataStates.jsx
// Three tiny, reusable presentational components covering the spec's
// "always show loading / empty / error states" requirement (section 19/26).
// Using these everywhere means every page fails and loads the same way.

export function LoadingState({ message = 'Loading...' }) {
    return <div className="loading-state">{message}</div>;
}

export function EmptyState({ message = 'Nothing to show yet.', action = null }) {
    return (
        <div className="empty-state">
            <p style={{ marginBottom: action ? 12 : 0 }}>{message}</p>
            {action}
        </div>
    );
}

export function ErrorState({ message = 'Something went wrong.', onRetry = null }) {
    return (
        <div className="empty-state">
            <p style={{ color: 'var(--color-danger)', marginBottom: onRetry ? 12 : 0 }}>{message}</p>
            {onRetry && <button className="btn btn-secondary btn-sm" onClick={onRetry}>Retry</button>}
        </div>
    );
}
