// components/ComingSoon.jsx
function ComingSoon({ title, phase }) {
    return (
        <div className="empty-state">
            <h3>{title}</h3>
            <p>This section is being built in Phase {phase}.</p>
        </div>
    );
}

export default ComingSoon;
