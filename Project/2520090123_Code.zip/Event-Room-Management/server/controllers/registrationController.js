// controllers/registrationController.js
const registrationModel = require('../models/registrationModel');
const eventModel = require('../models/eventModel');

// POST /api/registrations   body: { eventId, notes }
async function registerForEvent(req, res, next) {
    try {
        const { eventId, notes } = req.body;
        const userId = req.user.userId;

        if (!eventId) {
            return res.status(400).json({ success: false, message: 'eventId is required.' });
        }

        const event = await eventModel.getEventById(eventId);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }

        // Rule: registration only allowed for events that haven't ended yet
        if (new Date(event.end_date) < new Date()) {
            return res.status(400).json({
                success: false,
                message: 'This event has already ended. Registration is closed.'
            });
        }

        // Rule: no duplicate registration for the same event
        const existing = await registrationModel.findRegistration(userId, eventId);
        if (existing) {
            return res.status(409).json({
                success: false,
                message: 'You are already registered for this event.'
            });
        }

        // Rule: if a room is assigned, its capacity is the effective registration limit
        if (event.room_capacity) {
            const currentCount = await registrationModel.countActiveRegistrations(eventId);
            if (currentCount >= event.room_capacity) {
                return res.status(409).json({
                    success: false,
                    message: `Registration closed: this event has reached its capacity of ${event.room_capacity}.`
                });
            }
        }

        const registrationId = await registrationModel.createRegistration(userId, eventId, notes);
        const registration = await registrationModel.getRegistrationById(registrationId);

        res.status(201).json({
            success: true,
            message: 'Registration successful!',
            data: registration
        });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                success: false,
                message: 'You are already registered for this event.'
            });
        }
        err.publicMessage = 'Unable to register for this event. Please try again.';
        next(err);
    }
}

// GET /api/registrations/my
async function getMyRegistrations(req, res, next) {
    try {
        const registrations = await registrationModel.getMyRegistrations(req.user.userId);
        res.status(200).json({ success: true, message: 'Your registrations fetched.', data: registrations });
    } catch (err) {
        err.publicMessage = 'Unable to load your registrations.';
        next(err);
    }
}

// GET /api/registrations/event/:eventId  (admin only)
async function getRegistrationsForEvent(req, res, next) {
    try {
        const event = await eventModel.getEventById(req.params.eventId);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }
        const registrations = await registrationModel.getRegistrationsByEvent(req.params.eventId);
        res.status(200).json({
            success: true,
            message: 'Registrations for event fetched.',
            data: { event: { event_id: event.event_id, event_name: event.event_name }, registrations }
        });
    } catch (err) {
        err.publicMessage = 'Unable to load registrations for this event.';
        next(err);
    }
}

// GET /api/registrations  (admin only, supports ?eventId=&status=)
async function getAllRegistrations(req, res, next) {
    try {
        const registrations = await registrationModel.getAllRegistrations(req.query);
        res.status(200).json({ success: true, message: 'All registrations fetched.', data: registrations });
    } catch (err) {
        err.publicMessage = 'Unable to load registrations.';
        next(err);
    }
}

module.exports = { registerForEvent, getMyRegistrations, getRegistrationsForEvent, getAllRegistrations };
