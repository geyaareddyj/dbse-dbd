// controllers/roomController.js
const roomModel = require('../models/roomModel');

// Shared validation for create/update. Returns an error message string, or null if valid.
function validateRoomInput({ roomName, roomNumber, building, capacity, roomType, status }) {
    if (!roomName || !roomNumber || !building || capacity === undefined) {
        return 'Room name, room number, building and capacity are all required.';
    }
    if (isNaN(capacity) || Number(capacity) <= 0) {
        return 'Capacity must be a positive number.';
    }
    if (!roomModel.VALID_ROOM_TYPES.includes(roomType)) {
        return `Room type must be one of: ${roomModel.VALID_ROOM_TYPES.join(', ')}.`;
    }
    if (status && !roomModel.VALID_STATUSES.includes(status)) {
        return `Status must be one of: ${roomModel.VALID_STATUSES.join(', ')}.`;
    }
    return null;
}

// GET /api/rooms  (supports ?search=&roomType=&status=&minCapacity=)
async function getRooms(req, res, next) {
    try {
        const rooms = await roomModel.getAllRooms(req.query);
        res.status(200).json({ success: true, message: 'Rooms fetched.', data: rooms });
    } catch (err) {
        err.publicMessage = 'Unable to load rooms. Please try again.';
        next(err);
    }
}

// GET /api/rooms/:id
async function getRoomById(req, res, next) {
    try {
        const room = await roomModel.getRoomById(req.params.id);
        if (!room) {
            return res.status(404).json({ success: false, message: 'Room not found.' });
        }
        res.status(200).json({ success: true, message: 'Room fetched.', data: room });
    } catch (err) {
        err.publicMessage = 'Unable to load room details.';
        next(err);
    }
}

// POST /api/rooms  (admin only)
async function createRoom(req, res, next) {
    try {
        const validationError = validateRoomInput(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        const roomId = await roomModel.createRoom(req.body);
        const room = await roomModel.getRoomById(roomId);
        res.status(201).json({ success: true, message: 'Room created successfully.', data: room });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                success: false,
                message: 'A room with this room number already exists in this building.'
            });
        }
        err.publicMessage = 'Unable to create room. Please try again.';
        next(err);
    }
}

// PUT /api/rooms/:id  (admin only)
// If capacity is being reduced and upcoming events would exceed the new
// capacity, this returns a 409 warning UNLESS the client confirms the change
// by sending `confirmCapacityChange: true` in the request body (spec section 27).
async function updateRoom(req, res, next) {
    try {
        const roomId = req.params.id;
        const existingRoom = await roomModel.getRoomById(roomId);
        if (!existingRoom) {
            return res.status(404).json({ success: false, message: 'Room not found.' });
        }

        const validationError = validateRoomInput(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        const newCapacity = Number(req.body.capacity);
        const isCapacityReduced = newCapacity < existingRoom.capacity;

        if (isCapacityReduced && !req.body.confirmCapacityChange) {
            const affectedEvents = await roomModel.getEventsExceedingCapacity(roomId, newCapacity);
            if (affectedEvents.length > 0) {
                return res.status(409).json({
                    success: false,
                    message: `Warning: ${affectedEvents.length} upcoming event(s) expect more participants than the new capacity of ${newCapacity}. Confirm to proceed anyway.`,
                    data: { affectedEvents, requiresConfirmation: true }
                });
            }
        }

        await roomModel.updateRoom(roomId, req.body);
        const updatedRoom = await roomModel.getRoomById(roomId);
        res.status(200).json({ success: true, message: 'Room updated successfully.', data: updatedRoom });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                success: false,
                message: 'A room with this room number already exists in this building.'
            });
        }
        err.publicMessage = 'Unable to update room. Please try again.';
        next(err);
    }
}

// DELETE /api/rooms/:id  (admin only)
// Safe-delete: if the room has no historical bookings/events/schedules, it is
// removed outright. Otherwise it is marked Inactive instead (spec section 13C).
async function deleteRoom(req, res, next) {
    try {
        const roomId = req.params.id;
        const room = await roomModel.getRoomById(roomId);
        if (!room) {
            return res.status(404).json({ success: false, message: 'Room not found.' });
        }

        const hasHistory = await roomModel.roomHasHistoricalRecords(roomId);

        if (hasHistory) {
            await roomModel.updateRoomStatus(roomId, 'Inactive');
            return res.status(200).json({
                success: true,
                message: 'This room has booking history, so it was marked Inactive instead of being deleted.',
                data: { roomId, status: 'Inactive' }
            });
        }

        await roomModel.deleteRoom(roomId);
        res.status(200).json({ success: true, message: 'Room deleted successfully.' });
    } catch (err) {
        err.publicMessage = 'Unable to delete room. Please try again.';
        next(err);
    }
}

// GET /api/rooms/available?date=YYYY-MM-DD&startTime=HH:MM&endTime=HH:MM&minCapacity=optional
// THE most important endpoint in the project — checks every room against
// status, capacity, and existing schedule conflicts, and returns two lists:
// rooms that ARE available, and rooms that are NOT (with a plain-English reason).
async function checkAvailability(req, res, next) {
    try {
        const { date, startTime, endTime, minCapacity } = req.query;

        if (!date || !startTime || !endTime) {
            return res.status(400).json({
                success: false,
                message: 'date, startTime and endTime are all required.'
            });
        }

        if (startTime >= endTime) {
            return res.status(400).json({
                success: false,
                message: 'Start time must be before end time.'
            });
        }

        const requestedStart = `${date} ${startTime}:00`;
        const requestedEnd = `${date} ${endTime}:00`;

        const allRooms = await roomModel.getAllRooms({});
        const conflicts = await roomModel.findConflictingSchedules(requestedStart, requestedEnd);

        // Group conflicts by room_id for quick lookup
        const conflictsByRoom = {};
        conflicts.forEach((c) => {
            if (!conflictsByRoom[c.room_id]) conflictsByRoom[c.room_id] = [];
            conflictsByRoom[c.room_id].push(c);
        });

        const formatTime = (dateTimeStr) =>
            new Date(dateTimeStr).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

        const available = [];
        const unavailable = [];

        for (const room of allRooms) {
            if (room.status !== 'Available') {
                unavailable.push({ ...room, reason: `Room is currently marked as ${room.status}.` });
                continue;
            }

            if (minCapacity && room.capacity < Number(minCapacity)) {
                unavailable.push({
                    ...room,
                    reason: `Capacity (${room.capacity}) is less than the required ${minCapacity}.`
                });
                continue;
            }

            const roomConflicts = conflictsByRoom[room.room_id];
            if (roomConflicts && roomConflicts.length > 0) {
                const conflict = roomConflicts[0];
                unavailable.push({
                    ...room,
                    reason: `Already booked for "${conflict.event_name}" from ${formatTime(conflict.start_time)} to ${formatTime(conflict.end_time)}.`
                });
                continue;
            }

            available.push(room);
        }

        res.status(200).json({
            success: true,
            message: 'Availability checked.',
            data: {
                requested: { date, startTime, endTime, minCapacity: minCapacity || null },
                available,
                unavailable
            }
        });
    } catch (err) {
        err.publicMessage = 'Unable to check room availability. Please try again.';
        next(err);
    }
}

module.exports = { getRooms, getRoomById, createRoom, updateRoom, deleteRoom, checkAvailability };
