// controllers/eventController.js
const eventModel = require('../models/eventModel');

function validateEventInput({ eventName, organizer, eventType, startDate, endDate, expectedParticipants }) {
    if (!eventName || !organizer || !eventType || !startDate || !endDate) {
        return 'Event name, organizer, event type, start date and end date are all required.';
    }
    if (!eventModel.VALID_EVENT_TYPES.includes(eventType)) {
        return `Event type must be one of: ${eventModel.VALID_EVENT_TYPES.join(', ')}.`;
    }
    if (new Date(startDate) >= new Date(endDate)) {
        return 'Start date/time must be before end date/time.';
    }
    if (expectedParticipants !== undefined && Number(expectedParticipants) < 0) {
        return 'Expected participants cannot be negative.';
    }
    return null;
}

// GET /api/events  (supports ?search=&eventType=&date=&organizer=)
async function getEvents(req, res, next) {
    try {
        const events = await eventModel.getAllEvents(req.query);
        res.status(200).json({ success: true, message: 'Events fetched.', data: events });
    } catch (err) {
        err.publicMessage = 'Unable to load events. Please try again.';
        next(err);
    }
}

// GET /api/events/:id
async function getEventById(req, res, next) {
    try {
        const event = await eventModel.getEventById(req.params.id);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }
        res.status(200).json({ success: true, message: 'Event fetched.', data: event });
    } catch (err) {
        err.publicMessage = 'Unable to load event details.';
        next(err);
    }
}

// POST /api/events  (admin only)
// Creates the event first (always without a room). If `roomId` is included
// in the body, a room-assignment attempt runs immediately afterward — if that
// fails, the event still exists (just unassigned) and the specific reason is returned.
async function createEvent(req, res, next) {
    try {
        const validationError = validateEventInput(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        const eventId = await eventModel.createEvent(req.body);

        if (req.body.roomId) {
            try {
                await eventModel.assignRoomToEvent(eventId, req.body.roomId, req.user.userId);
            } catch (assignErr) {
                const event = await eventModel.getEventById(eventId);
                return res.status(201).json({
                    success: true,
                    message: `Event created, but room assignment failed: ${assignErr.message}`,
                    data: event
                });
            }
        }

        const event = await eventModel.getEventById(eventId);
        res.status(201).json({ success: true, message: 'Event created successfully.', data: event });
    } catch (err) {
        err.publicMessage = 'Unable to create event. Please try again.';
        next(err);
    }
}

// PUT /api/events/:id  (admin only)
// Updates the event's own fields. Does NOT touch room assignment — use
// PUT /api/events/:id/assign-room for that, so the two concerns stay separate.
// Exception: if the event's time changes while a room IS assigned, we
// re-validate that assignment against the new time to avoid silently creating
// a conflict, and unassign the room if it no longer fits.
async function updateEvent(req, res, next) {
    try {
        const eventId = req.params.id;
        const existingEvent = await eventModel.getEventById(eventId);
        if (!existingEvent) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }

        const validationError = validateEventInput(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        await eventModel.updateEventFields(eventId, req.body);

        let warning = null;
        if (existingEvent.room_id) {
            try {
                await eventModel.assignRoomToEvent(eventId, existingEvent.room_id, req.user.userId);
            } catch (assignErr) {
                await eventModel.unassignRoom(eventId);
                warning = `Room assignment was removed because the new schedule conflicts: ${assignErr.message}`;
            }
        }

        const updatedEvent = await eventModel.getEventById(eventId);
        res.status(200).json({
            success: true,
            message: warning || 'Event updated successfully.',
            data: updatedEvent
        });
    } catch (err) {
        err.publicMessage = 'Unable to update event. Please try again.';
        next(err);
    }
}

// DELETE /api/events/:id  (admin only)
async function deleteEvent(req, res, next) {
    try {
        const event = await eventModel.getEventById(req.params.id);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }
        await eventModel.deleteEvent(req.params.id);
        res.status(200).json({ success: true, message: 'Event deleted successfully.' });
    } catch (err) {
        err.publicMessage = 'Unable to delete event. Please try again.';
        next(err);
    }
}

// PUT /api/events/:id/assign-room  (admin only)  body: { roomId } or { roomId: null } to unassign
async function assignRoom(req, res, next) {
    try {
        const eventId = req.params.id;
        const { roomId } = req.body;

        const event = await eventModel.getEventById(eventId);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }

        if (!roomId) {
            await eventModel.unassignRoom(eventId);
            const updated = await eventModel.getEventById(eventId);
            return res.status(200).json({ success: true, message: 'Room unassigned from event.', data: updated });
        }

        const result = await eventModel.assignRoomToEvent(eventId, roomId, req.user.userId);
        const updated = await eventModel.getEventById(eventId);
        res.status(200).json({
            success: true,
            message: `Room ${result.roomNumber} assigned to event successfully.`,
            data: updated
        });
    } catch (err) {
        // These are expected, user-facing validation failures — not server errors.
        if (['ROOM_INACTIVE', 'CAPACITY_EXCEEDED', 'SCHEDULE_CONFLICT', 'ROOM_NOT_FOUND', 'EVENT_NOT_FOUND'].includes(err.code)) {
            const statusCode = err.code === 'ROOM_NOT_FOUND' || err.code === 'EVENT_NOT_FOUND' ? 404 : 409;
            return res.status(statusCode).json({ success: false, message: err.message });
        }
        err.publicMessage = 'Unable to assign room. Please try again.';
        next(err);
    }
}

module.exports = { getEvents, getEventById, createEvent, updateEvent, deleteEvent, assignRoom };
