// controllers/occupancyController.js
const occupancyModel = require('../models/occupancyModel');
const eventModel = require('../models/eventModel');
const roomModel = require('../models/roomModel');

// Occupancy Percentage = (actual_occupancy / room_capacity) * 100 (spec section 6)
// Bucketed into the exact labels from the spec's examples: 45%→Normal, 80%→High,
// 95%→Near Capacity, 100%+→Over Capacity.
function calculateOccupancy(actualOccupancy, roomCapacity) {
    if (!roomCapacity || roomCapacity <= 0) {
        return { percentage: null, label: 'Unknown' };
    }
    const percentage = Math.round((actualOccupancy / roomCapacity) * 100);
    let label;
    if (percentage >= 100) label = 'Over Capacity';
    else if (percentage >= 90) label = 'Near Capacity';
    else if (percentage >= 60) label = 'High';
    else label = 'Normal';
    return { percentage, label };
}

function attachOccupancyStats(record) {
    const { percentage, label } = calculateOccupancy(record.actual_occupancy, record.room_capacity);
    return { ...record, occupancyPercentage: percentage, occupancyLabel: label };
}

function validateNonNegative({ expectedParticipants, registeredParticipants, actualOccupancy }) {
    const fields = { expectedParticipants, registeredParticipants, actualOccupancy };
    for (const [key, value] of Object.entries(fields)) {
        if (value !== undefined && Number(value) < 0) {
            return `${key} cannot be negative.`;
        }
    }
    return null;
}

// GET /api/occupancy  (admin only, supports ?eventId=&roomId=&date=)
async function getOccupancyRecords(req, res, next) {
    try {
        const records = await occupancyModel.getAllOccupancy(req.query);
        res.status(200).json({
            success: true,
            message: 'Occupancy records fetched.',
            data: records.map(attachOccupancyStats)
        });
    } catch (err) {
        err.publicMessage = 'Unable to load occupancy records.';
        next(err);
    }
}

// POST /api/occupancy  (admin only)
// body: { eventId, roomId, date, expectedParticipants?, registeredParticipants?, actualOccupancy }
// expectedParticipants/registeredParticipants are auto-filled from the event
// and its live registration count if not supplied, so the admin usually only
// needs to type in the actual headcount after the event happens.
async function createOccupancyRecord(req, res, next) {
    try {
        const { eventId, roomId, date, actualOccupancy } = req.body;

        if (!eventId || !roomId || !date || actualOccupancy === undefined) {
            return res.status(400).json({
                success: false,
                message: 'eventId, roomId, date and actualOccupancy are all required.'
            });
        }

        const validationError = validateNonNegative(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        const event = await eventModel.getEventById(eventId);
        if (!event) {
            return res.status(404).json({ success: false, message: 'Event not found.' });
        }
        const room = await roomModel.getRoomById(roomId);
        if (!room) {
            return res.status(404).json({ success: false, message: 'Room not found.' });
        }

        const expectedParticipants = req.body.expectedParticipants ?? event.expected_participants;
        const registeredParticipants = req.body.registeredParticipants ?? await occupancyModel.countRegisteredParticipants(eventId);

        const occupancyId = await occupancyModel.createOccupancyRecord({
            eventId, roomId, date, expectedParticipants, registeredParticipants, actualOccupancy
        });

        const record = await occupancyModel.getOccupancyById(occupancyId);
        res.status(201).json({ success: true, message: 'Occupancy record created.', data: attachOccupancyStats(record) });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                success: false,
                message: 'An occupancy record already exists for this event, room and date. Please update it instead.'
            });
        }
        err.publicMessage = 'Unable to create occupancy record.';
        next(err);
    }
}

// PUT /api/occupancy/:id  (admin only)
async function updateOccupancyRecord(req, res, next) {
    try {
        const occupancyId = req.params.id;
        const existing = await occupancyModel.getOccupancyById(occupancyId);
        if (!existing) {
            return res.status(404).json({ success: false, message: 'Occupancy record not found.' });
        }

        const validationError = validateNonNegative(req.body);
        if (validationError) {
            return res.status(400).json({ success: false, message: validationError });
        }

        const expectedParticipants = req.body.expectedParticipants ?? existing.expected_participants;
        const registeredParticipants = req.body.registeredParticipants ?? existing.registered_participants;
        const actualOccupancy = req.body.actualOccupancy ?? existing.actual_occupancy;

        await occupancyModel.updateOccupancyRecord(occupancyId, { expectedParticipants, registeredParticipants, actualOccupancy });
        const updated = await occupancyModel.getOccupancyById(occupancyId);
        res.status(200).json({ success: true, message: 'Occupancy record updated.', data: attachOccupancyStats(updated) });
    } catch (err) {
        err.publicMessage = 'Unable to update occupancy record.';
        next(err);
    }
}

module.exports = { getOccupancyRecords, createOccupancyRecord, updateOccupancyRecord };
