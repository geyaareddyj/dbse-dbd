// controllers/healthController.js
const { pool } = require('../config/db');

// GET /api/health
// Confirms the API is running AND can talk to MySQL.
async function checkHealth(req, res, next) {
    try {
        const [rows] = await pool.query('SELECT 1 + 1 AS result');
        res.status(200).json({
            success: true,
            message: 'Server and database connection are healthy.',
            data: {
                server: 'running',
                database: 'connected',
                testQueryResult: rows[0].result // should be 2
            }
        });
    } catch (err) {
        err.publicMessage = 'Could not connect to the database.';
        next(err);
    }
}

module.exports = { checkHealth };
