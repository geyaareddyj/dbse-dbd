// controllers/bookingController.js
const bookingModel = require('../models/bookingModel');

// GET /api/bookings  (admin only, supports ?roomId=&eventId=&status=)
async function getBookings(req, res, next) {
    try {
        const bookings = await bookingModel.getAllBookings(req.query);
        res.status(200).json({ success: true, message: 'Bookings fetched.', data: bookings });
    } catch (err) {
        err.publicMessage = 'Unable to load bookings.';
        next(err);
    }
}

// GET /api/bookings/:id  (admin only)
async function getBookingById(req, res, next) {
    try {
        const booking = await bookingModel.getBookingById(req.params.id);
        if (!booking) {
            return res.status(404).json({ success: false, message: 'Booking not found.' });
        }
        res.status(200).json({ success: true, message: 'Booking fetched.', data: booking });
    } catch (err) {
        err.publicMessage = 'Unable to load booking details.';
        next(err);
    }
}

// POST /api/bookings  (admin only)  body: { eventId, roomId }
// This is an alternate entry point into the SAME room-assignment workflow used
// by PUT /api/events/:id/assign-room — useful when working from a "Manage
// Bookings" screen rather than an individual event's page.
async function createBooking(req, res, next) {
    try {
        const { eventId, roomId } = req.body;
        if (!eventId || !roomId) {
            return res.status(400).json({ success: false, message: 'eventId and roomId are both required.' });
        }

        const bookingId = await bookingModel.createBooking(eventId, roomId, req.user.userId);
        const booking = await bookingModel.getBookingById(bookingId);
        res.status(201).json({ success: true, message: 'Booking created successfully.', data: booking });
    } catch (err) {
        if (['ROOM_INACTIVE', 'CAPACITY_EXCEEDED', 'SCHEDULE_CONFLICT', 'ROOM_NOT_FOUND', 'EVENT_NOT_FOUND'].includes(err.code)) {
            const statusCode = err.code === 'ROOM_NOT_FOUND' || err.code === 'EVENT_NOT_FOUND' ? 404 : 409;
            return res.status(statusCode).json({ success: false, message: err.message });
        }
        err.publicMessage = 'Unable to create booking. Please try again.';
        next(err);
    }
}

// PUT /api/bookings/:id  (admin only)  body: { status: "Cancelled" }
// Bookings are only ever transitioned to Cancelled here — times/rooms are
// changed by re-assigning a room on the event (Phase 6), to avoid two
// different endpoints being able to silently create conflicting schedules.
async function updateBookingStatus(req, res, next) {
    try {
        const { status } = req.body;
        if (status !== 'Cancelled') {
            return res.status(400).json({
                success: false,
                message: 'Bookings can only be updated to status "Cancelled". To change a room or time, reassign the room on the event instead.'
            });
        }

        await bookingModel.cancelBooking(req.params.id);
        const booking = await bookingModel.getBookingById(req.params.id);
        res.status(200).json({ success: true, message: 'Booking cancelled successfully.', data: booking });
    } catch (err) {
        if (err.code === 'BOOKING_NOT_FOUND') {
            return res.status(404).json({ success: false, message: 'Booking not found.' });
        }
        err.publicMessage = 'Unable to update booking.';
        next(err);
    }
}

// DELETE /api/bookings/:id  (admin only)
async function deleteBooking(req, res, next) {
    try {
        await bookingModel.deleteBooking(req.params.id);
        res.status(200).json({ success: true, message: 'Booking deleted successfully.' });
    } catch (err) {
        if (err.code === 'BOOKING_NOT_FOUND') {
            return res.status(404).json({ success: false, message: 'Booking not found.' });
        }
        err.publicMessage = 'Unable to delete booking.';
        next(err);
    }
}

module.exports = { getBookings, getBookingById, createBooking, updateBookingStatus, deleteBooking };
