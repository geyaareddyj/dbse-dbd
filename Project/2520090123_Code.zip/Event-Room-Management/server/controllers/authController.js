// controllers/authController.js
const bcrypt = require('bcrypt');
const { findUserByEmail, findUserById, createUser } = require('../models/userModel');
const generateToken = require('../utils/generateToken');

const SALT_ROUNDS = 10;

// Strips the password hash before sending a user object back to the client
function toSafeUser(user) {
    const { password_hash, ...safeUser } = user;
    return safeUser;
}

// POST /api/auth/register
async function register(req, res, next) {
    try {
        const { name, email, password, department } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Name, email and password are required.'
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters long.'
            });
        }

        const existingUser = await findUserByEmail(email);
        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: 'An account with this email already exists.'
            });
        }

        const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
        const userId = await createUser({ name, email, passwordHash, department });
        const newUser = await findUserById(userId);
        const token = generateToken(newUser);

        return res.status(201).json({
            success: true,
            message: 'Registration successful.',
            data: { user: newUser, token }
        });
    } catch (err) {
        err.publicMessage = 'Registration failed. Please try again.';
        next(err);
    }
}

// POST /api/auth/login
async function login(req, res, next) {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email and password are required.'
            });
        }

        const user = await findUserByEmail(email);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        const passwordMatches = await bcrypt.compare(password, user.password_hash);
        if (!passwordMatches) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        const token = generateToken(user);

        return res.status(200).json({
            success: true,
            message: 'Login successful.',
            data: { user: toSafeUser(user), token }
        });
    } catch (err) {
        err.publicMessage = 'Login failed. Please try again.';
        next(err);
    }
}

// GET /api/auth/me  (protected — used to verify a token is valid)
async function getCurrentUser(req, res, next) {
    try {
        const user = await findUserById(req.user.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }
        return res.status(200).json({ success: true, message: 'Current user fetched.', data: { user } });
    } catch (err) {
        err.publicMessage = 'Could not fetch current user.';
        next(err);
    }
}

// GET /api/auth/admin-check  (protected + admin-only — used to verify role-based access works)
function adminCheck(req, res) {
    res.status(200).json({
        success: true,
        message: `Welcome, admin ${req.user.name}. You have admin access.`
    });
}

module.exports = { register, login, getCurrentUser, adminCheck };
