// middleware/authMiddleware.js
const jwt = require('jsonwebtoken');

// Verifies the JWT sent in the Authorization header ("Bearer <token>").
// On success, attaches the decoded payload to req.user for later use.
function protect(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
            success: false,
            message: 'You must be logged in to access this resource.'
        });
    }

    const token = authHeader.split(' ')[1];

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // { userId, role, name }
        next();
    } catch (err) {
        return res.status(401).json({
            success: false,
            message: 'Your session has expired or is invalid. Please log in again.'
        });
    }
}

// Must be used AFTER protect(). Blocks any non-admin from proceeding.
function adminOnly(req, res, next) {
    if (req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            message: 'This action is restricted to administrators.'
        });
    }
    next();
}

module.exports = { protect, adminOnly };
