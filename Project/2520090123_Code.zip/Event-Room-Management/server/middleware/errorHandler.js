// middleware/errorHandler.js
// Catches errors from routes/controllers and returns a consistent JSON shape.
// This keeps raw SQL/JS errors from ever reaching the frontend.

function errorHandler(err, req, res, next) {
    console.error('ERROR:', err.message);

    // Known MySQL duplicate-entry error -> friendly message
    if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
            success: false,
            message: 'This record already exists. Please use different details.'
        });
    }

    // Fallback: never leak raw error details to the client
    return res.status(err.statusCode || 500).json({
        success: false,
        message: err.publicMessage || 'Something went wrong. Please try again.'
    });
}

// 404 handler for routes that don't exist
function notFound(req, res) {
    res.status(404).json({
        success: false,
        message: 'The requested endpoint does not exist.'
    });
}

module.exports = { errorHandler, notFound };
