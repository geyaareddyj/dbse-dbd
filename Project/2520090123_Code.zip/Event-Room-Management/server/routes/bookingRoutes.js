// routes/bookingRoutes.js
const express = require('express');
const router = express.Router();
const {
    getBookings,
    getBookingById,
    createBooking,
    updateBookingStatus,
    deleteBooking
} = require('../controllers/bookingController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// Bookings are an admin-facing concept (spec: "Manage Bookings" is an admin page)
router.get('/', protect, adminOnly, getBookings);
router.get('/:id', protect, adminOnly, getBookingById);
router.post('/', protect, adminOnly, createBooking);
router.put('/:id', protect, adminOnly, updateBookingStatus);
router.delete('/:id', protect, adminOnly, deleteBooking);

module.exports = router;
