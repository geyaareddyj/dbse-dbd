// routes/roomRoutes.js
const express = require('express');
const router = express.Router();
const { getRooms, getRoomById, createRoom, updateRoom, deleteRoom, checkAvailability } = require('../controllers/roomController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// IMPORTANT: /available must be declared BEFORE /:id, otherwise Express
// would treat "available" as a room ID and route it to getRoomById instead.
router.get('/available', protect, checkAvailability);

// Any logged-in user (student or admin) can view rooms
router.get('/', protect, getRooms);
router.get('/:id', protect, getRoomById);

// Only admins can modify rooms
router.post('/', protect, adminOnly, createRoom);
router.put('/:id', protect, adminOnly, updateRoom);
router.delete('/:id', protect, adminOnly, deleteRoom);

module.exports = router;
