// routes/eventRoutes.js
const express = require('express');
const router = express.Router();
const { getEvents, getEventById, createEvent, updateEvent, deleteEvent, assignRoom } = require('../controllers/eventController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// Any logged-in user can view events
router.get('/', protect, getEvents);
router.get('/:id', protect, getEventById);

// Admin-only actions
router.post('/', protect, adminOnly, createEvent);
router.put('/:id', protect, adminOnly, updateEvent);
router.delete('/:id', protect, adminOnly, deleteEvent);
router.put('/:id/assign-room', protect, adminOnly, assignRoom);

module.exports = router;
