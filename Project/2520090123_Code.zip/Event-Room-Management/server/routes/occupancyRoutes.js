// routes/occupancyRoutes.js
const express = require('express');
const router = express.Router();
const { getOccupancyRecords, createOccupancyRecord, updateOccupancyRecord } = require('../controllers/occupancyController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.get('/', protect, adminOnly, getOccupancyRecords);
router.post('/', protect, adminOnly, createOccupancyRecord);
router.put('/:id', protect, adminOnly, updateOccupancyRecord);

module.exports = router;
