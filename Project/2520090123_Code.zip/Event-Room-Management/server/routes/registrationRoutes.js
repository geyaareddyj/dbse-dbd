// routes/registrationRoutes.js
const express = require('express');
const router = express.Router();
const {
    registerForEvent,
    getMyRegistrations,
    getRegistrationsForEvent,
    getAllRegistrations
} = require('../controllers/registrationController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// IMPORTANT: specific paths ("/my", "/event/:eventId") must come before
// any catch-all route, so Express doesn't misroute them.
router.get('/my', protect, getMyRegistrations);
router.get('/event/:eventId', protect, adminOnly, getRegistrationsForEvent);
router.get('/', protect, adminOnly, getAllRegistrations);
router.post('/', protect, registerForEvent);

module.exports = router;
