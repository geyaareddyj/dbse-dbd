// routes/authRoutes.js
const express = require('express');
const router = express.Router();
const { register, login, getCurrentUser, adminCheck } = require('../controllers/authController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, getCurrentUser); // protected — needs a valid token
router.get('/admin-check', protect, adminOnly, adminCheck); // protected + admin-only, for testing role guard

module.exports = router;
