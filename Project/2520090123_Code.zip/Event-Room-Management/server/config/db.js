// config/db.js
// Creates a reusable MySQL connection pool using credentials from .env

const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    // Forces mysql2 to treat DATETIME columns as UTC wall-clock values,
    // regardless of the host machine's local timezone. Without this, a
    // DATETIME of '2026-09-25 10:00:00' could come back shifted by several
    // hours on a server whose TZ isn't UTC — a subtle bug that would only
    // show up after deployment, not in local testing on a UTC machine.
    timezone: 'Z'
});

// Simple helper to confirm the database is reachable when the server starts
async function testConnection() {
    const connection = await pool.getConnection();
    try {
        await connection.query('SELECT 1');
        console.log('✅ Connected to MySQL database:', process.env.DB_NAME);
    } finally {
        connection.release();
    }
}

module.exports = { pool, testConnection };
