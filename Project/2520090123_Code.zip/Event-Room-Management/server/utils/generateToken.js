// utils/generateToken.js
const jwt = require('jsonwebtoken');

// Payload kept minimal on purpose: just enough to identify the user
// and check their role, without leaking anything sensitive into the token.
function generateToken(user) {
    return jwt.sign(
        { userId: user.user_id, role: user.role, name: user.name },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '1d' }
    );
}

module.exports = generateToken;
