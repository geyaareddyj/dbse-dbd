// app.js
// Sets up the Express app: middleware, routes, and error handling.
// server.js is responsible for actually starting the server.

const express = require('express');
const cors = require('cors');
require('dotenv').config();

const healthRoutes = require('./routes/healthRoutes');
const authRoutes = require('./routes/authRoutes');
const roomRoutes = require('./routes/roomRoutes');
const eventRoutes = require('./routes/eventRoutes');
const registrationRoutes = require('./routes/registrationRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const occupancyRoutes = require('./routes/occupancyRoutes');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app = express();

// ---- Global middleware ----
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json());

// ---- Routes ----
app.use('/api/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/occupancy', occupancyRoutes);

// All planned resource routes are now wired up. Only the React frontend
// (Phases 10-13) remains.

// ---- 404 + error handling (must stay last) ----
app.use(notFound);
app.use(errorHandler);

module.exports = app;
