// models/roomModel.js
const { pool } = require('../config/db');

const VALID_ROOM_TYPES = ['Classroom', 'Lab', 'Seminar Hall', 'Conference Room', 'Auditorium'];
const VALID_STATUSES = ['Available', 'Maintenance', 'Inactive'];

// Builds a WHERE clause dynamically from optional search/filter params.
// Always uses parameterized values — never string-concatenates user input into SQL.
function buildRoomFilters({ search, roomType, status, minCapacity }) {
    const conditions = [];
    const params = [];

    if (search) {
        conditions.push('(room_number LIKE ? OR room_name LIKE ? OR building LIKE ?)');
        const term = `%${search}%`;
        params.push(term, term, term);
    }
    if (roomType) {
        conditions.push('room_type = ?');
        params.push(roomType);
    }
    if (status) {
        conditions.push('status = ?');
        params.push(status);
    }
    if (minCapacity) {
        conditions.push('capacity >= ?');
        params.push(Number(minCapacity));
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    return { whereClause, params };
}

async function getAllRooms(filters) {
    const { whereClause, params } = buildRoomFilters(filters);
    const [rows] = await pool.query(
        `SELECT * FROM rooms ${whereClause} ORDER BY building, room_number`,
        params
    );
    return rows;
}

async function getRoomById(roomId) {
    const [rows] = await pool.query('SELECT * FROM rooms WHERE room_id = ?', [roomId]);
    return rows[0];
}

async function createRoom(room) {
    const { roomName, roomNumber, building, capacity, roomType, equipment, status } = room;
    const [result] = await pool.query(
        `INSERT INTO rooms (room_name, room_number, building, capacity, room_type, equipment, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [roomName, roomNumber, building, capacity, roomType, equipment || null, status || 'Available']
    );
    return result.insertId;
}

async function updateRoom(roomId, room) {
    const { roomName, roomNumber, building, capacity, roomType, equipment, status } = room;
    await pool.query(
        `UPDATE rooms
         SET room_name = ?, room_number = ?, building = ?, capacity = ?,
             room_type = ?, equipment = ?, status = ?
         WHERE room_id = ?`,
        [roomName, roomNumber, building, capacity, roomType, equipment || null, status, roomId]
    );
}

async function updateRoomStatus(roomId, status) {
    await pool.query('UPDATE rooms SET status = ? WHERE room_id = ?', [status, roomId]);
}

// Returns upcoming/ongoing events assigned to this room that expect MORE
// participants than the proposed new capacity — used to warn the admin
// before silently creating a capacity problem (spec section 27).
async function getEventsExceedingCapacity(roomId, newCapacity) {
    const [rows] = await pool.query(
        `SELECT event_id, event_name, start_date, expected_participants
         FROM events
         WHERE room_id = ?
           AND expected_participants > ?
           AND end_date >= NOW()`,
        [roomId, newCapacity]
    );
    return rows;
}

// Historical usage check — used to decide whether a room can be hard-deleted
// or must instead be marked Inactive (spec section 13C / 28).
async function roomHasHistoricalRecords(roomId) {
    const [[bookingCount]] = await pool.query(
        'SELECT COUNT(*) AS count FROM bookings WHERE room_id = ?', [roomId]
    );
    const [[eventCount]] = await pool.query(
        'SELECT COUNT(*) AS count FROM events WHERE room_id = ?', [roomId]
    );
    const [[scheduleCount]] = await pool.query(
        'SELECT COUNT(*) AS count FROM room_schedules WHERE room_id = ?', [roomId]
    );
    return (bookingCount.count + eventCount.count + scheduleCount.count) > 0;
}

async function deleteRoom(roomId) {
    await pool.query('DELETE FROM rooms WHERE room_id = ?', [roomId]);
}

// Finds all schedule conflicts (existing bookings) that overlap a requested
// time window, across ALL rooms in one query — used by the availability check.
// Overlap rule (per spec): existing_start < requested_end AND existing_end > requested_start
async function findConflictingSchedules(startDateTime, endDateTime, excludeEventId = null) {
    let query = `
        SELECT rs.room_id, rs.start_time, rs.end_time, e.event_name
        FROM room_schedules rs
        JOIN events e ON rs.event_id = e.event_id
        WHERE rs.status = 'Scheduled'
          AND rs.start_time < ?
          AND rs.end_time > ?`;
    const params = [endDateTime, startDateTime];

    if (excludeEventId) {
        query += ' AND rs.event_id != ?';
        params.push(excludeEventId);
    }

    const [rows] = await pool.query(query, params);
    return rows;
}

// Convenience helper for a SINGLE room — used when assigning a room to an
// event (Phase 6), where we only need a yes/no + reason for one room_id.
async function getRoomConflicts(roomId, startDateTime, endDateTime, excludeEventId = null) {
    let query = `
        SELECT rs.start_time, rs.end_time, e.event_name
        FROM room_schedules rs
        JOIN events e ON rs.event_id = e.event_id
        WHERE rs.status = 'Scheduled'
          AND rs.room_id = ?
          AND rs.start_time < ?
          AND rs.end_time > ?`;
    const params = [roomId, endDateTime, startDateTime];

    if (excludeEventId) {
        query += ' AND rs.event_id != ?';
        params.push(excludeEventId);
    }

    const [rows] = await pool.query(query, params);
    return rows;
}

module.exports = {
    VALID_ROOM_TYPES,
    VALID_STATUSES,
    getAllRooms,
    getRoomById,
    createRoom,
    updateRoom,
    updateRoomStatus,
    getEventsExceedingCapacity,
    roomHasHistoricalRecords,
    deleteRoom,
    findConflictingSchedules,
    getRoomConflicts
};
