// models/bookingModel.js
const { pool } = require('../config/db');
const { assignRoomToEvent } = require('./eventModel');

function buildBookingFilters({ roomId, eventId, status }) {
    const conditions = [];
    const params = [];

    if (roomId) {
        conditions.push('b.room_id = ?');
        params.push(roomId);
    }
    if (eventId) {
        conditions.push('b.event_id = ?');
        params.push(eventId);
    }
    if (status) {
        conditions.push('b.status = ?');
        params.push(status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    return { whereClause, params };
}

// Admin's "Manage Bookings" list — joined with event/room/booked-by-user names
async function getAllBookings(filters) {
    const { whereClause, params } = buildBookingFilters(filters);
    const [rows] = await pool.query(
        `SELECT b.*, e.event_name, r.room_name, r.room_number, u.name AS booked_by
         FROM bookings b
         JOIN events e ON b.event_id = e.event_id
         JOIN rooms r ON b.room_id = r.room_id
         JOIN users u ON b.user_id = u.user_id
         ${whereClause}
         ORDER BY b.created_at DESC`,
        params
    );
    return rows;
}

async function getBookingById(bookingId) {
    const [rows] = await pool.query(
        `SELECT b.*, e.event_name, r.room_name, r.room_number, u.name AS booked_by
         FROM bookings b
         JOIN events e ON b.event_id = e.event_id
         JOIN rooms r ON b.room_id = r.room_id
         JOIN users u ON b.user_id = u.user_id
         WHERE b.booking_id = ?`,
        [bookingId]
    );
    return rows[0];
}

// Creating a booking IS assigning a room to an event — this deliberately
// reuses the exact same transactional workflow from eventModel (status/
// capacity/conflict checks, and writing both room_schedules + bookings
// together) rather than duplicating that logic here.
async function createBooking(eventId, roomId, adminUserId) {
    await assignRoomToEvent(eventId, roomId, adminUserId); // throws on failure, same as event assignment
    const [rows] = await pool.query(
        'SELECT booking_id FROM bookings WHERE event_id = ? AND room_id = ? ORDER BY created_at DESC LIMIT 1',
        [eventId, roomId]
    );
    return rows[0].booking_id;
}

// Shared cleanup used by both cancel and delete: cancels the matching
// room_schedule row, and clears the event's room_id IF this booking was
// the one currently occupying that room — keeps all three tables consistent.
async function releaseBooking(connection, booking) {
    await connection.query(
        "UPDATE room_schedules SET status = 'Cancelled' WHERE event_id = ? AND room_id = ?",
        [booking.event_id, booking.room_id]
    );
    await connection.query(
        'UPDATE events SET room_id = NULL WHERE event_id = ? AND room_id = ?',
        [booking.event_id, booking.room_id]
    );
}

async function cancelBooking(bookingId) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [[booking]] = await connection.query('SELECT * FROM bookings WHERE booking_id = ? FOR UPDATE', [bookingId]);
        if (!booking) {
            throw Object.assign(new Error('Booking not found.'), { code: 'BOOKING_NOT_FOUND' });
        }
        await connection.query("UPDATE bookings SET status = 'Cancelled' WHERE booking_id = ?", [bookingId]);
        await releaseBooking(connection, booking);
        await connection.commit();
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

async function deleteBooking(bookingId) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [[booking]] = await connection.query('SELECT * FROM bookings WHERE booking_id = ? FOR UPDATE', [bookingId]);
        if (!booking) {
            throw Object.assign(new Error('Booking not found.'), { code: 'BOOKING_NOT_FOUND' });
        }
        await releaseBooking(connection, booking);
        await connection.query('DELETE FROM bookings WHERE booking_id = ?', [bookingId]);
        await connection.commit();
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

module.exports = { getAllBookings, getBookingById, createBooking, cancelBooking, deleteBooking };
