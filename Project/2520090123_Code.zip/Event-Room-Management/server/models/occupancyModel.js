// models/occupancyModel.js
const { pool } = require('../config/db');

function buildOccupancyFilters({ eventId, roomId, date }) {
    const conditions = [];
    const params = [];

    if (eventId) {
        conditions.push('o.event_id = ?');
        params.push(eventId);
    }
    if (roomId) {
        conditions.push('o.room_id = ?');
        params.push(roomId);
    }
    if (date) {
        conditions.push('o.date = ?');
        params.push(date);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    return { whereClause, params };
}

// Joined with event/room details AND the room's capacity, since the
// occupancy-percentage calculation needs capacity but that lives on rooms.
async function getAllOccupancy(filters) {
    const { whereClause, params } = buildOccupancyFilters(filters);
    const [rows] = await pool.query(
        `SELECT o.*, e.event_name, r.room_name, r.room_number, r.capacity AS room_capacity
         FROM occupancy_records o
         JOIN events e ON o.event_id = e.event_id
         JOIN rooms r ON o.room_id = r.room_id
         ${whereClause}
         ORDER BY o.date DESC`,
        params
    );
    return rows;
}

async function getOccupancyById(occupancyId) {
    const [rows] = await pool.query(
        `SELECT o.*, e.event_name, r.room_name, r.room_number, r.capacity AS room_capacity
         FROM occupancy_records o
         JOIN events e ON o.event_id = e.event_id
         JOIN rooms r ON o.room_id = r.room_id
         WHERE o.occupancy_id = ?`,
        [occupancyId]
    );
    return rows[0];
}

// Counts registrations with status = 'Registered' — used to auto-fill
// registered_participants when the admin doesn't supply it manually.
async function countRegisteredParticipants(eventId) {
    const [[row]] = await pool.query(
        "SELECT COUNT(*) AS count FROM registrations WHERE event_id = ? AND status = 'Registered'",
        [eventId]
    );
    return row.count;
}

async function createOccupancyRecord({ eventId, roomId, date, expectedParticipants, registeredParticipants, actualOccupancy }) {
    const [result] = await pool.query(
        `INSERT INTO occupancy_records (event_id, room_id, date, expected_participants, registered_participants, actual_occupancy)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [eventId, roomId, date, expectedParticipants, registeredParticipants, actualOccupancy]
    );
    return result.insertId;
}

async function updateOccupancyRecord(occupancyId, { expectedParticipants, registeredParticipants, actualOccupancy }) {
    await pool.query(
        `UPDATE occupancy_records
         SET expected_participants = ?, registered_participants = ?, actual_occupancy = ?
         WHERE occupancy_id = ?`,
        [expectedParticipants, registeredParticipants, actualOccupancy, occupancyId]
    );
}

module.exports = {
    getAllOccupancy,
    getOccupancyById,
    countRegisteredParticipants,
    createOccupancyRecord,
    updateOccupancyRecord
};
