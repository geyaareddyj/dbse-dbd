// models/registrationModel.js
const { pool } = require('../config/db');

async function findRegistration(userId, eventId) {
    const [rows] = await pool.query(
        'SELECT * FROM registrations WHERE user_id = ? AND event_id = ?',
        [userId, eventId]
    );
    return rows[0];
}

async function countActiveRegistrations(eventId) {
    const [[row]] = await pool.query(
        "SELECT COUNT(*) AS count FROM registrations WHERE event_id = ? AND status = 'Registered'",
        [eventId]
    );
    return row.count;
}

async function createRegistration(userId, eventId, notes) {
    const [result] = await pool.query(
        `INSERT INTO registrations (user_id, event_id, status, notes)
         VALUES (?, ?, 'Registered', ?)`,
        [userId, eventId, notes || null]
    );
    return result.insertId;
}

async function getRegistrationById(registrationId) {
    const [rows] = await pool.query(
        `SELECT reg.*, e.event_name, e.start_date, e.end_date, u.name AS student_name, u.email AS student_email
         FROM registrations reg
         JOIN events e ON reg.event_id = e.event_id
         JOIN users u ON reg.user_id = u.user_id
         WHERE reg.registration_id = ?`,
        [registrationId]
    );
    return rows[0];
}

// A student's own registrations — includes event + assigned room details
async function getMyRegistrations(userId) {
    const [rows] = await pool.query(
        `SELECT reg.registration_id, reg.status, reg.registration_date, reg.notes,
                e.event_id, e.event_name, e.event_type, e.start_date, e.end_date,
                r.room_name, r.room_number
         FROM registrations reg
         JOIN events e ON reg.event_id = e.event_id
         LEFT JOIN rooms r ON e.room_id = r.room_id
         WHERE reg.user_id = ?
         ORDER BY e.start_date DESC`,
        [userId]
    );
    return rows;
}

// All registrations for one event — used by admins to see who signed up
async function getRegistrationsByEvent(eventId) {
    const [rows] = await pool.query(
        `SELECT reg.registration_id, reg.status, reg.registration_date, reg.notes,
                u.user_id, u.name AS student_name, u.email AS student_email, u.department
         FROM registrations reg
         JOIN users u ON reg.user_id = u.user_id
         WHERE reg.event_id = ?
         ORDER BY reg.registration_date ASC`,
        [eventId]
    );
    return rows;
}

// Admin-wide view, with optional filters — supports the Admin Dashboard's
// "Registrations" page (spec section 13)
async function getAllRegistrations({ eventId, status }) {
    const conditions = [];
    const params = [];

    if (eventId) {
        conditions.push('reg.event_id = ?');
        params.push(eventId);
    }
    if (status) {
        conditions.push('reg.status = ?');
        params.push(status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const [rows] = await pool.query(
        `SELECT reg.registration_id, reg.status, reg.registration_date, reg.notes,
                e.event_id, e.event_name,
                u.user_id, u.name AS student_name, u.email AS student_email
         FROM registrations reg
         JOIN events e ON reg.event_id = e.event_id
         JOIN users u ON reg.user_id = u.user_id
         ${whereClause}
         ORDER BY reg.registration_date DESC`,
        params
    );
    return rows;
}

module.exports = {
    findRegistration,
    countActiveRegistrations,
    createRegistration,
    getRegistrationById,
    getMyRegistrations,
    getRegistrationsByEvent,
    getAllRegistrations
};
