// models/eventModel.js
const { pool } = require('../config/db');

const VALID_EVENT_TYPES = ['Workshop', 'Seminar', 'Hackathon', 'Competition', 'Club Event', 'Meeting', 'Other'];

function buildEventFilters({ search, eventType, date, organizer }) {
    const conditions = [];
    const params = [];

    if (search) {
        conditions.push('event_name LIKE ?');
        params.push(`%${search}%`);
    }
    if (eventType) {
        conditions.push('event_type = ?');
        params.push(eventType);
    }
    if (date) {
        conditions.push('DATE(start_date) = ?');
        params.push(date);
    }
    if (organizer) {
        conditions.push('organizer LIKE ?');
        params.push(`%${organizer}%`);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    return { whereClause, params };
}

// Joins the assigned room's name/number in, since the frontend almost always needs it
async function getAllEvents(filters) {
    const { whereClause, params } = buildEventFilters(filters);
    const [rows] = await pool.query(
        `SELECT e.*, r.room_name, r.room_number, r.capacity AS room_capacity
         FROM events e
         LEFT JOIN rooms r ON e.room_id = r.room_id
         ${whereClause}
         ORDER BY e.start_date ASC`,
        params
    );
    return rows;
}

async function getEventById(eventId) {
    const [rows] = await pool.query(
        `SELECT e.*, r.room_name, r.room_number, r.capacity AS room_capacity
         FROM events e
         LEFT JOIN rooms r ON e.room_id = r.room_id
         WHERE e.event_id = ?`,
        [eventId]
    );
    return rows[0];
}

// Events are always created WITHOUT a room first. Assigning a room is a
// separate step (assignRoomToEvent) so a failed room check never leaves the
// event half-created — this keeps the two concerns cleanly separated.
async function createEvent(event) {
    const { eventName, description, organizer, eventType, startDate, endDate, expectedParticipants } = event;
    const [result] = await pool.query(
        `INSERT INTO events (event_name, description, organizer, event_type, start_date, end_date, expected_participants)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [eventName, description || null, organizer, eventType, startDate, endDate, expectedParticipants || 0]
    );
    return result.insertId;
}

async function updateEventFields(eventId, event) {
    const { eventName, description, organizer, eventType, startDate, endDate, expectedParticipants } = event;
    await pool.query(
        `UPDATE events
         SET event_name = ?, description = ?, organizer = ?, event_type = ?,
             start_date = ?, end_date = ?, expected_participants = ?
         WHERE event_id = ?`,
        [eventName, description || null, organizer, eventType, startDate, endDate, expectedParticipants || 0, eventId]
    );
}

async function deleteEvent(eventId) {
    // room_schedules, bookings, registrations and occupancy_records all have
    // ON DELETE CASCADE on event_id, so this cleanly removes everything linked
    // to the event too. No orphaned rows are left behind.
    await pool.query('DELETE FROM events WHERE event_id = ?', [eventId]);
}

// Removes the room assignment: deletes the schedule/booking rows and clears
// events.room_id, WITHOUT deleting the event itself.
async function unassignRoom(eventId) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        await connection.query('DELETE FROM room_schedules WHERE event_id = ?', [eventId]);
        await connection.query("UPDATE bookings SET status = 'Cancelled' WHERE event_id = ?", [eventId]);
        await connection.query('UPDATE events SET room_id = NULL WHERE event_id = ?', [eventId]);
        await connection.commit();
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

// THE core workflow from spec section 3: checks room status, capacity, and
// scheduling conflicts, then atomically updates events + room_schedules +
// bookings together. Throws a structured error ({code, message}) on failure
// so the controller can return the exact wording your spec asks for.
async function assignRoomToEvent(eventId, roomId, adminUserId) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const [[event]] = await connection.query('SELECT * FROM events WHERE event_id = ? FOR UPDATE', [eventId]);
        if (!event) {
            throw Object.assign(new Error('Event not found.'), { code: 'EVENT_NOT_FOUND' });
        }

        const [[room]] = await connection.query('SELECT * FROM rooms WHERE room_id = ? FOR UPDATE', [roomId]);
        if (!room) {
            throw Object.assign(new Error('Room not found.'), { code: 'ROOM_NOT_FOUND' });
        }

        // Check 1: is the room active?
        if (room.status !== 'Available') {
            throw Object.assign(
                new Error(`Room ${room.room_number} is currently marked as ${room.status} and cannot be assigned.`),
                { code: 'ROOM_INACTIVE' }
            );
        }

        // Check 2: is capacity sufficient?
        if (room.capacity < event.expected_participants) {
            throw Object.assign(
                new Error(`Room capacity is ${room.capacity} but this event expects ${event.expected_participants} participants.`),
                { code: 'CAPACITY_EXCEEDED' }
            );
        }

        // Check 3 & 4: does the room have a conflicting schedule at this event's time?
        // (excludes this event's own existing schedule row, so re-assigning the
        // SAME room to the SAME event doesn't falsely conflict with itself)
        const [conflicts] = await connection.query(
            `SELECT rs.start_time, rs.end_time, e.event_name
             FROM room_schedules rs
             JOIN events e ON rs.event_id = e.event_id
             WHERE rs.room_id = ?
               AND rs.status = 'Scheduled'
               AND rs.event_id != ?
               AND rs.start_time < ?
               AND rs.end_time > ?`,
            [roomId, eventId, event.end_date, event.start_date]
        );
        if (conflicts.length > 0) {
            const c = conflicts[0];
            const formatTime = (dt) => new Date(dt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            throw Object.assign(
                new Error(`Room ${room.room_number} is already booked from ${formatTime(c.start_time)} to ${formatTime(c.end_time)} (${c.event_name}).`),
                { code: 'SCHEDULE_CONFLICT' }
            );
        }

        // All checks passed — apply the assignment atomically.
        await connection.query('DELETE FROM room_schedules WHERE event_id = ?', [eventId]);
        await connection.query(
            `INSERT INTO room_schedules (room_id, event_id, start_time, end_time, status)
             VALUES (?, ?, ?, ?, 'Scheduled')`,
            [roomId, eventId, event.start_date, event.end_date]
        );
        await connection.query('UPDATE events SET room_id = ? WHERE event_id = ?', [roomId, eventId]);
        await connection.query(
            `INSERT INTO bookings (event_id, room_id, user_id, start_time, end_time, status)
             VALUES (?, ?, ?, ?, ?, 'Confirmed')`,
            [eventId, roomId, adminUserId, event.start_date, event.end_date]
        );

        await connection.commit();
        return { roomId, roomNumber: room.room_number };
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

module.exports = {
    VALID_EVENT_TYPES,
    getAllEvents,
    getEventById,
    createEvent,
    updateEventFields,
    deleteEvent,
    unassignRoom,
    assignRoomToEvent
};
