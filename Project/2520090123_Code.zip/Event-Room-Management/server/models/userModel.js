// models/userModel.js
// Plain SQL query functions for the users table.
// Kept simple on purpose — no ORM, just readable queries.

const { pool } = require('../config/db');

async function findUserByEmail(email) {
    const [rows] = await pool.query(
        'SELECT * FROM users WHERE email = ?',
        [email]
    );
    return rows[0]; // undefined if not found
}

async function findUserById(userId) {
    const [rows] = await pool.query(
        'SELECT user_id, name, email, role, department, created_at FROM users WHERE user_id = ?',
        [userId]
    );
    return rows[0];
}

async function createUser({ name, email, passwordHash, department }) {
    // Public registration always creates a 'student' account.
    // Admin accounts are created directly in the database (see seed.sql),
    // not through this public endpoint — this keeps the API safe by default.
    const [result] = await pool.query(
        `INSERT INTO users (name, email, password_hash, role, department)
         VALUES (?, ?, ?, 'student', ?)`,
        [name, email, passwordHash, department]
    );
    return result.insertId;
}

module.exports = { findUserByEmail, findUserById, createUser };
