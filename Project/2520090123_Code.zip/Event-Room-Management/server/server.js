// server.js
// Entry point: verifies the database is reachable, then starts the server.

require('dotenv').config();
const app = require('./app');
const { testConnection } = require('./config/db');

const PORT = process.env.PORT || 5000;

async function startServer() {
    try {
        await testConnection();
        app.listen(PORT, () => {
            console.log(`🚀 Server running on http://localhost:${PORT}`);
        });
    } catch (err) {
        console.error('❌ Failed to connect to the database. Server not started.');
        console.error(err.message);
        process.exit(1);
    }
}

startServer();
