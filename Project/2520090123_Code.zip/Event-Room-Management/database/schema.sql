-- ================================================================
-- Event and Room Occupancy Management System
-- Database Schema (MySQL 8.0+)
-- ================================================================

DROP DATABASE IF EXISTS event_room_management;
CREATE DATABASE event_room_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_room_management;

-- ----------------------------------------------------------------
-- 1. USERS
-- ----------------------------------------------------------------
CREATE TABLE users (
    user_id         INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('student', 'admin') NOT NULL DEFAULT 'student',
    department      VARCHAR(100),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------
-- 2. ROOMS
-- ----------------------------------------------------------------
CREATE TABLE rooms (
    room_id         INT AUTO_INCREMENT PRIMARY KEY,
    room_name       VARCHAR(100) NOT NULL,
    room_number     VARCHAR(20) NOT NULL,
    building        VARCHAR(100) NOT NULL,
    capacity        INT NOT NULL,
    room_type       ENUM('Classroom', 'Lab', 'Seminar Hall', 'Conference Room', 'Auditorium') NOT NULL,
    status          ENUM('Available', 'Maintenance', 'Inactive') NOT NULL DEFAULT 'Available',
    equipment       VARCHAR(255),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_room_number_building UNIQUE (room_number, building),
    CONSTRAINT chk_room_capacity_positive CHECK (capacity > 0)
);

-- ----------------------------------------------------------------
-- 3. EVENTS
-- ----------------------------------------------------------------
CREATE TABLE events (
    event_id                INT AUTO_INCREMENT PRIMARY KEY,
    event_name              VARCHAR(150) NOT NULL,
    description             TEXT,
    organizer               VARCHAR(150) NOT NULL,
    event_type              ENUM('Workshop', 'Seminar', 'Hackathon', 'Competition', 'Club Event', 'Meeting', 'Other') NOT NULL,
    start_date              DATETIME NOT NULL,
    end_date                DATETIME NOT NULL,
    expected_participants   INT NOT NULL DEFAULT 0,
    room_id                 INT NULL,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_event_room FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT chk_event_dates CHECK (start_date < end_date),
    CONSTRAINT chk_event_expected_participants CHECK (expected_participants >= 0)
);

CREATE INDEX idx_events_room ON events(room_id);
CREATE INDEX idx_events_dates ON events(start_date, end_date);

-- ----------------------------------------------------------------
-- 4. REGISTRATIONS
-- ----------------------------------------------------------------
CREATE TABLE registrations (
    registration_id     INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NOT NULL,
    event_id            INT NOT NULL,
    registration_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status              ENUM('Registered', 'Cancelled', 'Attended') NOT NULL DEFAULT 'Registered',
    notes               VARCHAR(255),
    CONSTRAINT fk_registration_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_registration_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT uq_user_event_registration UNIQUE (user_id, event_id)
);

CREATE INDEX idx_registrations_event ON registrations(event_id);
CREATE INDEX idx_registrations_user ON registrations(user_id);

-- ----------------------------------------------------------------
-- 5. ROOM_SCHEDULES  (authoritative source for conflict checking)
-- ----------------------------------------------------------------
CREATE TABLE room_schedules (
    schedule_id     INT AUTO_INCREMENT PRIMARY KEY,
    room_id         INT NOT NULL,
    event_id        INT NOT NULL,
    start_time      DATETIME NOT NULL,
    end_time        DATETIME NOT NULL,
    status          ENUM('Scheduled', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Scheduled',
    CONSTRAINT fk_schedule_room FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_schedule_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_schedule_times CHECK (start_time < end_time)
);

CREATE INDEX idx_schedules_room_time ON room_schedules(room_id, start_time, end_time);

-- ----------------------------------------------------------------
-- 6. BOOKINGS  (audit record of who reserved a room, for which event)
-- ----------------------------------------------------------------
CREATE TABLE bookings (
    booking_id      INT AUTO_INCREMENT PRIMARY KEY,
    event_id        INT NOT NULL,
    room_id         INT NOT NULL,
    user_id         INT NOT NULL,
    start_time      DATETIME NOT NULL,
    end_time        DATETIME NOT NULL,
    status          ENUM('Confirmed', 'Cancelled') NOT NULL DEFAULT 'Confirmed',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_booking_room FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_booking_times CHECK (start_time < end_time)
);

CREATE INDEX idx_bookings_room_time ON bookings(room_id, start_time, end_time);

-- ----------------------------------------------------------------
-- 7. OCCUPANCY_RECORDS
-- ----------------------------------------------------------------
CREATE TABLE occupancy_records (
    occupancy_id            INT AUTO_INCREMENT PRIMARY KEY,
    event_id                INT NOT NULL,
    room_id                 INT NOT NULL,
    date                    DATE NOT NULL,
    expected_participants   INT NOT NULL DEFAULT 0,
    registered_participants INT NOT NULL DEFAULT 0,
    actual_occupancy        INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_occupancy_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_occupancy_room FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT uq_event_room_date UNIQUE (event_id, room_id, date),
    CONSTRAINT chk_occupancy_non_negative CHECK (
        expected_participants >= 0 AND
        registered_participants >= 0 AND
        actual_occupancy >= 0
    )
);

CREATE INDEX idx_occupancy_room_date ON occupancy_records(room_id, date);
