-- ================================================================
-- Seed Data — Event and Room Occupancy Management System
-- All accounts below use the password: password123
-- (bcrypt hash generated with 10 salt rounds)
-- ================================================================

USE event_room_management;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE occupancy_records;
TRUNCATE TABLE bookings;
TRUNCATE TABLE room_schedules;
TRUNCATE TABLE registrations;
TRUNCATE TABLE events;
TRUNCATE TABLE rooms;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------
-- USERS (1 admin + 6 students)
-- ----------------------------------------------------------------
INSERT INTO users (name, email, password_hash, role, department) VALUES
('Admin User',        'admin@college.edu',      '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'admin',   'Administration'),
('Geya Reddy',        'geya.reddy@college.edu',  '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Computer Science'),
('Priyanka Kamtam',   'priyanka.k@college.edu',  '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Computer Science'),
('Rahul Verma',       'rahul.verma@college.edu', '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Electronics'),
('Ananya Rao',        'ananya.rao@college.edu',  '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Mechanical'),
('Kiran Kumar',       'kiran.kumar@college.edu', '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Civil'),
('Sneha Patil',       'sneha.patil@college.edu', '$2b$10$altKGnmNAl7CCyftS8iYf.7G2IvzdVWEKwou59w8aU09ClIHvpQia', 'student', 'Information Technology');

-- ----------------------------------------------------------------
-- ROOMS (10 rooms covering all statuses/types/capacities)
-- ----------------------------------------------------------------
INSERT INTO rooms (room_name, room_number, building, capacity, room_type, status, equipment) VALUES
('Classroom A',        'BH-101', 'Block B', 40,  'Classroom',       'Available',   'Whiteboard, Projector'),
('Classroom B',        'BH-102', 'Block B', 60,  'Classroom',       'Available',   'Whiteboard, Projector, AC'),
('Computer Lab 1',     'BH-201', 'Block B', 60,  'Lab',             'Available',   'Computers, Projector, AC'),
('Electronics Lab',    'BH-202', 'Block B', 40,  'Lab',             'Maintenance', 'Workbenches, Oscilloscopes'),
('Seminar Hall',       'BH-204', 'Block B', 120, 'Seminar Hall',    'Available',   'Projector, AC, WiFi, Mic'),
('Conference Room',    'BH-301', 'Block C', 100, 'Conference Room', 'Available',   'Projector, AC, WiFi, Video Conf'),
('Main Auditorium',    'BH-401', 'Block C', 200, 'Auditorium',      'Available',   'Stage, Sound System, Projector, AC'),
('Classroom C',        'BH-103', 'Block B', 60,  'Classroom',       'Available',   'Whiteboard, Projector'),
('Small Meeting Room', 'BH-105', 'Block B', 20,  'Conference Room', 'Inactive',    'Whiteboard'),
('Physics Lab',        'BH-203', 'Block B', 40,  'Lab',             'Available',   'Lab Equipment, AC');

-- ----------------------------------------------------------------
-- EVENTS (mix of upcoming events, with/without room, with/without registrations)
-- ----------------------------------------------------------------
INSERT INTO events (event_name, description, organizer, event_type, start_date, end_date, expected_participants, room_id) VALUES
('AI Workshop',            'Hands-on workshop on AI fundamentals and tools.',   'CS Department',   'Workshop',   '2026-09-25 10:00:00', '2026-09-25 12:00:00', 100, 5),
('Code Sprint Hackathon',  '24-hour hackathon for student teams.',              'Coding Club',     'Hackathon',  '2026-09-27 09:00:00', '2026-09-28 09:00:00', 150, 7),
('Web Dev Seminar',        'Seminar on modern web development practices.',      'IT Department',   'Seminar',    '2026-09-26 14:00:00', '2026-09-26 16:00:00', 80,  6),
('Robotics Club Meeting',  'Monthly meeting for robotics club members.',        'Robotics Club',   'Club Event', '2026-09-24 16:00:00', '2026-09-24 17:30:00', 30,  1),
('Faculty Planning Meet',  'Internal faculty planning discussion.',             'Administration',  'Meeting',    '2026-09-29 11:00:00', '2026-09-29 12:00:00', 15,  NULL),
('Chess Championship',     'Inter-department chess competition.',               'Sports Committee','Competition','2026-10-02 10:00:00', '2026-10-02 17:00:00', 40,  2);

-- ----------------------------------------------------------------
-- REGISTRATIONS (some events have registrations, one has none)
-- ----------------------------------------------------------------
INSERT INTO registrations (user_id, event_id, status, notes) VALUES
(2, 1, 'Registered', NULL),
(3, 1, 'Registered', NULL),
(4, 1, 'Registered', NULL),
(5, 1, 'Registered', NULL),
(2, 2, 'Registered', NULL),
(3, 2, 'Registered', NULL),
(6, 2, 'Registered', NULL),
(7, 3, 'Registered', NULL),
(4, 3, 'Cancelled', 'Schedule conflict'),
(5, 4, 'Registered', NULL),
(6, 4, 'Attended', NULL);
-- Note: 'Faculty Planning Meet' (event_id 5) and 'Chess Championship' (event_id 6)
-- intentionally have no registrations yet, to demo the empty state.

-- ----------------------------------------------------------------
-- ROOM_SCHEDULES (authoritative time blocks — used for conflict checks)
-- ----------------------------------------------------------------
INSERT INTO room_schedules (room_id, event_id, start_time, end_time, status) VALUES
(5, 1, '2026-09-25 10:00:00', '2026-09-25 12:00:00', 'Scheduled'),
(7, 2, '2026-09-27 09:00:00', '2026-09-28 09:00:00', 'Scheduled'),
(6, 3, '2026-09-26 14:00:00', '2026-09-26 16:00:00', 'Scheduled'),
(1, 4, '2026-09-24 16:00:00', '2026-09-24 17:30:00', 'Scheduled'),
(2, 6, '2026-10-02 10:00:00', '2026-10-02 17:00:00', 'Scheduled');
-- BH-204 (room 5) is therefore OCCUPIED on 25-09-2026 10:00-12:00, and
-- AVAILABLE outside that window — good for demoing the availability check.

-- ----------------------------------------------------------------
-- BOOKINGS (admin's reservation actions, mirroring the schedules above)
-- ----------------------------------------------------------------
INSERT INTO bookings (event_id, room_id, user_id, start_time, end_time, status) VALUES
(1, 5, 1, '2026-09-25 10:00:00', '2026-09-25 12:00:00', 'Confirmed'),
(2, 7, 1, '2026-09-27 09:00:00', '2026-09-28 09:00:00', 'Confirmed'),
(3, 6, 1, '2026-09-26 14:00:00', '2026-09-26 16:00:00', 'Confirmed'),
(4, 1, 1, '2026-09-24 16:00:00', '2026-09-24 17:30:00', 'Confirmed'),
(6, 2, 1, '2026-10-02 10:00:00', '2026-10-02 17:00:00', 'Confirmed');

-- ----------------------------------------------------------------
-- OCCUPANCY_RECORDS (demonstrates normal / high / near-capacity examples)
-- ----------------------------------------------------------------
INSERT INTO occupancy_records (event_id, room_id, date, expected_participants, registered_participants, actual_occupancy) VALUES
(1, 5, '2026-09-25', 100, 4,  92),   -- Seminar Hall, capacity 120 -> ~77% "High"
(3, 6, '2026-09-26', 80,  1,  38),   -- Conference Room, capacity 100 -> 38% "Normal"
(4, 1, '2026-09-24', 30,  2,  29);   -- Classroom A, capacity 40 -> ~73% "High"
