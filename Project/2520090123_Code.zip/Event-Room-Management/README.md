# Event and Room Occupancy Management System

A web-based application for managing room availability, event scheduling, and participant registrations on a college campus — built for **Database Systems Engineering and Distributed Backend Development (25CS1302E)**, Trimester 4, Section 10.

**Team:** J. Geya Reddy, Kamtam Priyanka

---

## 1. Project Overview

Students can browse events, register for them, and check which rooms are free at a given date and time. Admins can manage rooms and events, assign rooms to events (with automatic conflict/capacity checks), track bookings, and monitor room occupancy.

The core problem this system solves is **preventing double-booked rooms** — every room assignment is checked against existing schedules, room status, and capacity before it's allowed to happen.

## 2. Features

**Students**
- Browse, search, and filter upcoming events
- View full event details
- Register for events (duplicate registrations and capacity limits are enforced)
- View "My Registrations" with live status
- Check room availability for any date/time
- View a personal profile

**Admins**
- Full room management (add/edit/delete, with a safety check before shrinking a room's capacity below what upcoming events need)
- Full event management, including assigning a room to an event (checked against the room's status, capacity, and existing schedule)
- Booking management (view, cancel, delete)
- View all student registrations, filterable by event/status
- Occupancy tracking with an automatically calculated percentage and status badge (Normal / High / Near Capacity / Over Capacity)
- A dashboard with live stats: total rooms, rooms occupied right now, upcoming events, today's events, total registrations, and capacity warnings

## 3. Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React.js (Vite) |
| Backend | Node.js, Express.js |
| Database | MySQL 8 |
| Auth | JWT + bcrypt |
| Tools used during development | MySQL Workbench, Postman, VS Code, Git/GitHub |

## 4. Folder Structure

```
event-room-management/
├── client/                 # React frontend
│   └── src/
│       ├── components/     # Shared UI: Modal, Navbar, StatusBadge, layouts, etc.
│       ├── context/        # AuthContext, ToastContext
│       ├── pages/          # admin/, student/, rooms/, and top-level pages
│       ├── services/       # One file per API resource (roomService.js, eventService.js, ...)
│       └── utils/          # dateUtils.js (timezone-safe date helpers)
├── server/                 # Express backend
│   ├── config/db.js        # MySQL connection pool
│   ├── controllers/        # One file per resource
│   ├── middleware/         # authMiddleware.js, errorHandler.js
│   ├── models/             # One file per resource — all raw SQL lives here
│   ├── routes/             # One file per resource
│   ├── utils/generateToken.js
│   ├── app.js               # Express app + middleware wiring
│   └── server.js            # Entry point — verifies DB connection, then listens
├── database/
│   ├── schema.sql          # Full schema: 7 tables, PKs/FKs/UNIQUE/CHECK constraints
│   └── seed.sql            # Realistic demo data (see section 11 below)
├── postman/
│   └── Event-Room-Management.postman_collection.json
├── .env.example
└── .gitignore
```

## 5. Requirements

- Node.js 18+ and npm
- MySQL 8.0+ (MySQL Workbench recommended for inspecting the database)
- Git

## 6. MySQL Setup

From the project root:

```
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql
```

Verify it worked:
```sql
USE event_room_management;
SHOW TABLES;
SELECT * FROM rooms;
```
You should see 7 tables and 10 seeded rooms.

## 7. Environment Variables

Copy the template and fill in your own values:
```
cp .env.example server/.env
```

| Variable | Meaning |
|---|---|
| `PORT` | Port the Express server runs on (default 5000) |
| `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` | Your MySQL connection details |
| `JWT_SECRET` | Any long random string — used to sign login tokens |
| `JWT_EXPIRES_IN` | How long a login session lasts (default `1d`) |
| `CLIENT_URL` | The frontend's URL, for CORS (default `http://localhost:5173`) |

**Never commit your real `.env` file** — `.gitignore` already excludes it.

## 8. Backend Setup

```
cd server
npm install
npm run dev
```

You should see:
```
✅ Connected to MySQL database: event_room_management
🚀 Server running on http://localhost:5000
```
If you instead see a database connection error, double-check `server/.env`.

## 9. Frontend Setup

In a second terminal:
```
cd client
npm install
npm run dev
```
Open the URL it prints (typically `http://localhost:5173`). The frontend calls `/api/...` and Vite automatically forwards those requests to the backend on port 5000 — no extra configuration needed.

## 10. How to Run (quick reference)

1. `mysql -u root -p < database/schema.sql` then `... < database/seed.sql` (once)
2. Terminal 1: `cd server && npm install && npm run dev`
3. Terminal 2: `cd client && npm install && npm run dev`
4. Open `http://localhost:5173`

## 11. Default Login Credentials

All seeded accounts use the password **`password123`**.

| Role | Email |
|---|---|
| Admin | `admin@college.edu` |
| Student | `geya.reddy@college.edu` |
| Student | `priyanka.k@college.edu` |
| Student | `rahul.verma@college.edu`, `ananya.rao@college.edu`, `kiran.kumar@college.edu`, `sneha.patil@college.edu` |

The seed data also includes: an Available room, a room under Maintenance, an Inactive room, a room too small for one of the events, an event with several registrations, an event with none, and existing room schedules/bookings/occupancy records — so the app is demo-ready immediately after setup.

## 12. API Endpoints

All endpoints are prefixed with `/api`. 🔒 = requires a valid login token (`Authorization: Bearer <token>`). 🔒👑 = admin only.

**Auth**
| Method | Endpoint | Description |
|---|---|---|
| POST | `/auth/register` | Create a student account |
| POST | `/auth/login` | Log in, returns a JWT |
| GET 🔒 | `/auth/me` | Get the current logged-in user |

**Rooms**
| Method | Endpoint | Description |
|---|---|---|
| GET 🔒 | `/rooms` | List rooms (`?search=&roomType=&status=&minCapacity=`) |
| GET 🔒 | `/rooms/:id` | Get one room |
| GET 🔒 | `/rooms/available` | Check availability (`?date=&startTime=&endTime=&minCapacity=`) |
| POST 🔒👑 | `/rooms` | Create a room |
| PUT 🔒👑 | `/rooms/:id` | Update a room (409 warning if reducing capacity affects upcoming events) |
| DELETE 🔒👑 | `/rooms/:id` | Delete, or mark Inactive if it has booking history |

**Events**
| Method | Endpoint | Description |
|---|---|---|
| GET 🔒 | `/events` | List events (`?search=&eventType=&date=&organizer=`) |
| GET 🔒 | `/events/:id` | Get one event |
| POST 🔒👑 | `/events` | Create an event |
| PUT 🔒👑 | `/events/:id` | Update an event |
| DELETE 🔒👑 | `/events/:id` | Delete (cascades registrations/schedule/bookings) |
| PUT 🔒👑 | `/events/:id/assign-room` | Assign (`{roomId}`) or unassign (`{roomId: null}`) a room |

**Registrations**
| Method | Endpoint | Description |
|---|---|---|
| POST 🔒 | `/registrations` | Register for an event (`{eventId}`) |
| GET 🔒 | `/registrations/my` | The current student's registrations |
| GET 🔒👑 | `/registrations/event/:eventId` | Everyone registered for one event |
| GET 🔒👑 | `/registrations` | All registrations (`?eventId=&status=`) |

**Bookings**
| Method | Endpoint | Description |
|---|---|---|
| GET 🔒👑 | `/bookings` | List bookings (`?roomId=&eventId=&status=`) |
| POST 🔒👑 | `/bookings` | Create (`{eventId, roomId}`) — same checks as assign-room |
| PUT 🔒👑 | `/bookings/:id` | Cancel (`{status: "Cancelled"}`) |
| DELETE 🔒👑 | `/bookings/:id` | Delete |

**Occupancy**
| Method | Endpoint | Description |
|---|---|---|
| GET 🔒👑 | `/occupancy` | List records (`?eventId=&roomId=&date=`) |
| POST 🔒👑 | `/occupancy` | Create (`{eventId, roomId, date, actualOccupancy}`) |
| PUT 🔒👑 | `/occupancy/:id` | Update headcount |

**Health**
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Confirms the server and database are both reachable |

Every response follows the same shape:
```json
{ "success": true, "message": "...", "data": { ... } }
```

## 13. Postman Testing

Import `postman/Event-Room-Management.postman_collection.json` into Postman. It's organized into folders (Auth, Rooms, Events, Registrations, Bookings, Occupancy, Health) and uses collection variables so requests chain together automatically:

1. Run **Auth → Login (Admin)** and **Auth → Login (Student)** first — each one automatically saves its token into `{{adminToken}}` / `{{studentToken}}`, used by every other request.
2. Run **Events → Create Event (admin)** — it saves the new event's ID into `{{eventId}}`.
3. From there, **Events → Assign Room**, **Registrations → Register for Event**, and **Occupancy → Create Occupancy Record** all use that same `{{eventId}}` automatically.
4. Try running **Registrations → Register for Event** twice in a row to see the duplicate-registration rejection, and **Rooms → Update Room (admin)** to see the capacity-warning flow.

No manual token copy-pasting needed — that's what the built-in test scripts on the Login requests are for.

## 14. Database ER Diagram Reference

Seven tables: `users`, `rooms`, `events`, `registrations`, `room_schedules`, `bookings`, `occupancy_records`. See `database/schema.sql` for the full definitions, including every PK/FK/UNIQUE/CHECK constraint.

One design decision worth explaining in a viva: **`room_schedules` is the single source of truth** for conflict-checking (every availability check and every room assignment reads from it), while **`bookings` is an audit trail** of *who* booked a room and *when* — both are written together, atomically, inside one database transaction whenever a room is assigned to an event (see `assignRoomToEvent()` in `server/models/eventModel.js`), so they can never drift out of sync.

## 15. Common Troubleshooting

| Problem | Fix |
|---|---|
| Backend says "Failed to connect to the database" | Check `server/.env` — wrong `DB_PASSWORD` is the usual cause. Also confirm MySQL is actually running (`mysql -u root -p` should connect). |
| `ER_DUP_ENTRY` or a raw SQL error shown to the user | Shouldn't happen — every known duplicate case (email, room number, occupancy record) is caught and shown as a plain-English message. If you see one, it's a bug — check `server/middleware/errorHandler.js`. |
| Frontend shows "Something went wrong" on every request | Usually means the backend isn't running, or is running on a different port than `vite.config.js` expects (5000). |
| Login works but every other request returns 401 | Your token may have expired (`JWT_EXPIRES_IN` in `.env`) — just log in again. |
| MySQL won't start: "Unable to setup unix socket lock file" | A stale `mysqld` process is holding the socket. Run `sudo pkill -9 mysqld`, delete `/var/run/mysqld/mysqld.sock` and `mysqld.pid` if they exist, then `sudo service mysql start` again. |
| Edit Event form shows the wrong time | Fixed as of the current version — if you see this, make sure you're on the latest `ManageEvents.jsx` and `utils/dateUtils.js` (this was a real timezone bug caught during testing; see the code comments in `dateUtils.js` for why it happened). |
| "Room is already booked" but you don't see why | Check `room_schedules` for that room — that table is the authoritative source for every conflict check in the app. |
